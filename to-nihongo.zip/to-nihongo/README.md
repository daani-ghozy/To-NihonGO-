# To NihonGO! 日本語

Situs gratis untuk belajar bahasa Jepang N5 (berdasarkan Minna no Nihongo I): tebak kosakata Bab 1-25,
hiragana, katakana, latihan partikel dan kata kerja, kanji, latihan membaca, serta panduan JLPT/JFT
dan magang/kerja di Jepang.

Pengembang: Daani.

## Isi folder

| File               | Fungsi                                          |
| ------------------ | ----------------------------------------------- |
| `index.html`       | Struktur semua halaman                          |
| `css/style.css`    | Tampilan, termasuk tema terang (pink) dan gelap |
| `js/theme-init.js` | Menerapkan tema sebelum halaman tampil          |
| `js/data.js`       | Data kosakata Bab 1-25                          |
| `js/app.js`        | Logika: login, kuis, latihan, riwayat, tema     |

Ini situs statis. Tidak ada server atau database, jadi tidak ada yang perlu dipasang di server.

## Cara menayangkan (gratis)

Upload seluruh isi folder ini (bukan hanya `index.html`) ke salah satu layanan hosting statis:

- **Cloudflare Pages**: buat proyek, pilih direct upload, unggah folder ini.
- **Netlify**: buka halaman Netlify Drop, seret folder ini. Nama situs bisa diganti di pengaturan
  menjadi misalnya `to-nihongo`, sehingga linknya `to-nihongo.netlify.app` (jika masih tersedia).
- **GitHub Pages**: buat repository, unggah semua file, aktifkan Pages dari pengaturan repository.

Nama domain sendiri (misalnya `tonihongo.com`) bersifat opsional dan berbayar di penyedia domain.

## Cara kerja data

- Akun, skor, dan riwayat disimpan di `localStorage` browser masing-masing pemakai.
- Data tidak dikirim ke server dan tidak bisa dilihat pemakai lain.
- Data hilang jika pemakai menghapus data browser, ganti HP, atau pindah browser.
- Password hanya dicek di browser dan disimpan sebagai teks biasa, jadi bukan keamanan sungguhan.

## Mengubah isi

- Kosakata: edit `js/data.js`.
- Warna dan tampilan: edit `css/style.css` (variabel warna ada di bagian paling atas).
- Teks halaman: edit `index.html`.

Font Jepang (Noto Sans JP) dimuat dari Google Fonts, jadi butuh internet saat pertama dibuka.
