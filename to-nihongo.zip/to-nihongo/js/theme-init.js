/* Menerapkan tema (terang atau gelap) sebelum halaman tampil agar tidak berkedip. */
try {
  var _s = JSON.parse(localStorage.getItem("kb_set") || "{}"),
    _t = _s.theme || "auto";
  if (_t === "auto")
    _t = window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  document.documentElement.setAttribute("data-theme", _t);
} catch (e) {}
