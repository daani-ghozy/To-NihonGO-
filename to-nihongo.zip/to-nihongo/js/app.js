/* To NihonGO! - logika aplikasi (login, kuis, latihan, tema, riwayat).
   Membutuhkan js/data.js (variabel D) yang dimuat lebih dulu. */
// ===== Kosakata: membangun daftar W dari data di data.js =====
var W = [];
Object.keys(D).forEach(function (l) {
  D[l].split(";").forEach(function (s) {
    var a = s.split("|");
    W.push({ k: a[0], j: a[1], m: a[2], l: +l });
  });
});

// ===== Helper dasar dan penyimpanan lokal (localStorage) =====
var $ = function (i) {
  return document.getElementById(i);
};
function ls(k, v) {
  try {
    if (v === undefined) {
      var r = localStorage.getItem(k);
      return r ? JSON.parse(r) : null;
    }
    localStorage.setItem(k, JSON.stringify(v));
  } catch (e) {
    if (v === undefined) return mem[k] === undefined ? null : mem[k];
    mem[k] = v;
    return v;
  }
}
var mem = {};
var users = ls("kb_users") || {},
  cur = ls("kb_cur"),
  mode = "local",
  CU = null,
  S = Object.assign(
    {
      mode: "jp",
      dir: "mix",
      n: 10,
      furi: true,
      ls: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
      ],
      theme: "auto",
      snd: true,
    },
    ls("kb_set") || {},
  );
function fresh() {
  return { best: 0, played: 0, right: 0, total: 0, h: [] };
}
var CL = null,
  CT = 0;
function save() {
  ls("kb_users", users);
  ls("kb_set", S);
  if (CL) {
    clearTimeout(CT);
    CT = setTimeout(cloudPush, 500);
  }
}
// ===== Cadangan opsional ke akun Claude (aktif hanya jika dibuka di dalam Claude) =====
function cloudPush() {
  if (!CL) return;
  try {
    CL.set({ u: users, s: S, t: Date.now() }).catch(function () {});
  } catch (e) {}
}
async function cloudInit() {
  var st = "Data tersimpan di browser ini.";
  try {
    var u = await claude.use("user"),
      d = await claude.use("db");
    if (u && d) {
      var id = await u.id();
      if (id) {
        CL = d.collection("data/users/" + id).doc("backup");
        var sn = await CL.get();
        if (sn.exists) {
          var c = sn.data() || {},
            cu = c.u || {};
          Object.keys(cu).forEach(function (n) {
            var a = users[n],
              b = cu[n];
            if (
              b &&
              (!a ||
                (b.played || 0) > (a.played || 0) ||
                ((b.played || 0) === (a.played || 0) && (b.h || []).length > (a.h || []).length))
            )
              users[n] = b;
          });
          ls("kb_users", users);
        }
        cloudPush();
        st =
          "Cadangan otomatis ke akun Claude aktif. Data tetap ada walau keluar, ganti browser, atau ganti perangkat.";
      }
    }
  } catch (e) {}
  $("sy").textContent = st;
  if (cur && users[cur] && !$("home").classList.contains("hide")) home();
}
window.addEventListener("pagehide", function () {
  cloudPush();
});
// ===== Furigana: pemisahan bacaan per kanji =====
var FS = {
  先生: "せん|せい",
  教師: "きょう|し",
  学生: "がく|せい",
  会社員: "かい|しゃ|いん",
  社員: "しゃ|いん",
  銀行員: "ぎん|こう|いん",
  医者: "い|しゃ",
  研究者: "けん|きゅう|しゃ",
  大学: "だい|がく",
  病院: "びょう|いん",
  何歳: "なん|さい",
  失礼: "しつ|れい",
  名前: "な|まえ",
  韓国: "かん|こく",
  中国: "ちゅう|ごく",
  日本: "に|ほん",
  辞書: "じ|しょ",
  雑誌: "ざっ|し",
  新聞: "しん|ぶん",
  手帳: "て|ちょう",
  名刺: "めい|し",
  鉛筆: "えん|ぴつ",
  時計: "=",
  土産: "=",
  英語: "えい|ご",
  日本語: "に|ほん|ご",
  世話: "せ|わ",
  教室: "きょう|しつ",
  食堂: "しょく|どう",
  事務所: "じ|む|しょ",
  会議室: "かい|ぎ|しつ",
  受付: "うけ|つけ",
  部屋: "=",
  階段: "かい|だん",
  自動販売機: "じ|どう|はん|ばい|き",
  電話: "でん|わ",
  会社: "かい|しゃ",
  地下: "ち|か",
  何階: "なん|がい",
  新大阪: "しん|おお|さか",
  勉強: "べん|きょう",
  銀行: "ぎん|こう",
  郵便局: "ゆう|びん|きょく",
  図書館: "と|しょ|かん",
  美術館: "び|じゅつ|かん",
  何時: "なん|じ",
  何分: "なん|ぷん",
  午前: "ご|ぜん",
  午後: "ご|ご",
  今晩: "こん|ばん",
  昼休: "ひる|やす",
  試験: "し|けん",
  会議: "かい|ぎ",
  映画: "えい|が",
  毎朝: "まい|あさ",
  毎晩: "まい|ばん",
  毎日: "まい|にち",
  月曜日: "げつ|よう|び",
  火曜日: "か|よう|び",
  水曜日: "すい|よう|び",
  木曜日: "もく|よう|び",
  金曜日: "きん|よう|び",
  土曜日: "ど|よう|び",
  日曜日: "にち|よう|び",
  何曜日: "なん|よう|び",
  大変: "たい|へん",
  番号: "ばん|ごう",
  何番: "なん|ばん",
  学校: "がっ|こう",
  飛行機: "ひ|こう|き",
  電車: "でん|しゃ",
  地下鉄: "ち|か|てつ",
  新幹線: "しん|かん|せん",
  自転車: "じ|てん|しゃ",
  友達: "とも|だち",
  彼女: "かの|じょ",
  家族: "か|ぞく",
  一人: "=",
  先週: "せん|しゅう",
  今週: "こん|しゅう",
  来週: "らい|しゅう",
  先月: "せん|げつ",
  今月: "こん|げつ",
  来月: "らい|げつ",
  去年: "きょ|ねん",
  来年: "らい|ねん",
  何年: "なん|ねん",
  何月: "なん|がつ",
  何日: "なん|にち",
  誕生日: "たん|じょう|び",
  番線: "ばん|せん",
  普通: "ふ|つう",
  急行: "きゅう|こう",
  特急: "とっ|きゅう",
  甲子園: "こう|し|えん",
  大阪城: "おお|さか|じょう",
  野菜: "や|さい",
  果物: "くだ|もの",
  紅茶: "こう|ちゃ",
  牛乳: "ぎゅう|にゅう",
  手紙: "て|がみ",
  写真: "しゃ|しん",
  宿題: "しゅく|だい",
  花見: "はな|み",
  時々: "とき|どき",
  年賀状: "ねん|が|じょう",
  荷物: "に|もつ",
  切符: "きっ|ぷ",
  有名: "ゆう|めい",
  親切: "しん|せつ",
  元気: "げん|き",
  便利: "べん|り",
  生活: "せい|かつ",
  仕事: "し|ごと",
  一杯: "いっ|ぱい",
  金閣寺: "きん|かく|じ",
  奈良公園: "な|ら|こう|えん",
  富士山: "ふ|じ|さん",
  七人: "しち|にん",
  上手: "=",
  下手: "=",
  料理: "りょう|り",
  野球: "や|きゅう",
  旅行: "りょ|こう",
  音楽: "おん|がく",
  歌舞伎: "か|ぶ|き",
  漢字: "かん|じ",
  時間: "じ|かん",
  用事: "よう|じ",
  約束: "やく|そく",
  主人: "しゅ|じん",
  全然: "ぜん|ぜん",
  残念: "ざん|ねん",
  今度: "こん|ど",
  電池: "でん|ち",
  冷蔵庫: "れい|ぞう|こ",
  公園: "こう|えん",
  喫茶店: "きっ|さ|てん",
  東京: "とう|きょう",
  切手: "きっ|て",
  封筒: "ふう|とう",
  両親: "りょう|しん",
  兄弟: "きょう|だい",
  外国: "がい|こく",
  留学生: "りゅう|がく|せい",
  週間: "しゅう|かん",
  全部: "ぜん|ぶ",
  天気: "てん|き",
  船便: "ふな|びん",
  航空便: "こう|くう|びん",
  簡単: "かん|たん",
  季節: "き|せつ",
  空港: "くう|こう",
  世界: "せ|かい",
  刺身: "さし|み",
  豚肉: "ぶた|にく",
  牛肉: "ぎゅう|にく",
  紅葉: "=",
  祇園祭: "ぎ|おん|まつり",
  結婚: "けっ|こん",
  食事: "しょく|じ",
  散歩: "さん|ぽ",
  美術: "び|じゅつ",
  週末: "しゅう|まつ",
  正月: "しょう|がつ",
  注文: "ちゅう|もん",
  定食: "てい|しょく",
  少々: "しょう|しょう",
  別々: "べつ|べつ",
  手伝: "て|つだ",
  電気: "でん|き",
  住所: "じゅう|しょ",
  地図: "ち|ず",
  砂糖: "さ|とう",
  問題: "もん|だい",
  信号: "しん|ごう",
  研究: "けん|きゅう",
  資料: "し|りょう",
  時刻表: "じ|こく|ひょう",
  製品: "せい|ひん",
  電子辞書: "でん|し|じ|しょ",
  経済: "けい|ざい",
  市役所: "し|やく|しょ",
  高校: "こう|こう",
  歯医者: "は|い|しゃ",
  独身: "どく|しん",
  日本橋: "にっ|ぽん|ばし",
  見学: "けん|がく",
  神社: "じん|じゃ",
  暗証番号: "あん|しょう|ばん|ごう",
  金額: "きん|がく",
  確認: "かく|にん",
  心配: "しん|ぱい",
  残業: "ざん|ぎょう",
  出張: "しゅっ|ちょう",
  大切: "たい|せつ",
  大丈夫: "だい|じょう|ぶ",
  禁煙: "きん|えん",
  健康保険証: "けん|こう|ほ|けん|しょう",
  病気: "びょう|き",
  上着: "うわ|ぎ",
  下着: "した|ぎ",
  大事: "だい|じ",
  運転: "うん|てん",
  予約: "よ|やく",
  現金: "げん|きん",
  趣味: "しゅ|み",
  日記: "にっ|き",
  課長: "か|ちょう",
  部長: "ぶ|ちょう",
  社長: "しゃ|ちょう",
  動物: "どう|ぶつ",
  故郷: "=",
  秋葉原: "あき|は|ばら",
  掃除: "そう|じ",
  洗濯: "せん|たく",
  練習: "れん|しゅう",
  相撲: "す|もう",
  調子: "ちょう|し",
  一度: "いち|ど",
  乾杯: "かん|ぱい",
  無理: "む|り",
  葛飾北斎: "かつ|しか|ほく|さい",
  修理: "しゅう|り",
  着物: "き|もの",
  留学: "りゅう|がく",
  不便: "ふ|べん",
  自動車: "じ|どう|しゃ",
  交通: "こう|つう",
  物価: "ぶっ|か",
  放送: "ほう|そう",
  天才: "てん|さい",
  試合: "し|あい",
  意見: "い|けん",
  地球: "ち|きゅう",
  最近: "さい|きん",
  牧師: "ぼく|し",
  天神祭: "てん|じん|まつり",
  吉野山: "よし|の|やま",
  帽子: "ぼう|し",
  眼鏡: "=",
  弁当: "べん|とう",
  都合: "つ|ごう",
  家賃: "や|ちん",
  和室: "わ|しつ",
  布団: "ふ|とん",
  万里: "ばん|り",
  長城: "ちょう|じょう",
  故障: "こ|しょう",
  交差点: "こう|さ|てん",
  駐車場: "ちゅう|しゃ|じょう",
  建物: "たて|もの",
  何回: "なん|かい",
  聖徳太子: "しょう|とく|たい|し",
  法隆寺: "ほう|りゅう|じ",
  紹介: "しょう|かい",
  案内: "あん|ない",
  説明: "せつ|めい",
  準備: "じゅん|び",
  菓子: "か|し",
  自分: "じ|ぶん",
  田舎: "=",
  意味: "い|み",
  転勤: "てん|きん",
  頑張: "がん|ば",
  今日: "=",
  昨日: "=",
  田中: "た|なか",
  京都: "きょう|と",
  明日: "=",
  椅子: "い|す",
  花子: "はな|こ",
  大阪: "おお|さか",
  山田: "やま|だ",
  一緒: "いっ|しょ",
  奈良: "な|ら",
};
var FZ = {};
function rr(run, rd) {
  if (run.length === 1) return "<ruby>" + run + "<rt>" + rd + "</rt></ruby>";
  var sp = FS[run];
  if (sp && sp !== "=" && !/[0-9]/.test(run)) {
    var a = sp.split("|");
    if (a.length === run.length && a.join("") === rd)
      return a
        .map(function (x, i) {
          return "<ruby>" + run[i] + "<rt>" + x + "</rt></ruby>";
        })
        .join("");
  }
  return "<ruby>" + run + "<rt>" + rd + "</rt></ruby>";
}
function al(tk, k, i, p) {
  if (i === tk.length) return p === k.length ? [] : null;
  var t = tk[i];
  if (t[0] === "L") {
    if (k.indexOf(t[1], p) === p) {
      var r = al(tk, k, i + 1, p + t[1].length);
      return r && [t].concat(r);
    }
    return null;
  }
  for (var l = 1; p + l <= k.length; l++) {
    var r2 = al(tk, k, i + 1, p + l);
    if (r2) return [["K", t[1], k.slice(p, p + l)]].concat(r2);
  }
  return null;
}
function fz(j, k) {
  var key = j + "|" + k;
  if (FZ[key]) return FZ[key];
  var dk = /[0-9]/.test(k),
    tk = [],
    cur = "",
    ty = "",
    c,
    i;
  for (i = 0; i < j.length; i++) {
    c = j.charAt(i);
    var t = /[\u4E00-\u9FFF々]/.test(c) || (!dk && /[0-9]/.test(c)) ? "K" : "L";
    if (t !== ty && cur) {
      tk.push([ty, cur]);
      cur = "";
    }
    ty = t;
    cur += c;
  }
  if (cur) tk.push([ty, cur]);
  var a = al(tk, k, 0, 0);
  return (FZ[key] = a
    ? a
        .map(function (x) {
          return x[0] === "L" ? x[1] : rr(x[1], x[2]);
        })
        .join("")
    : "<ruby>" + j + "<rt>" + k + "</rt></ruby>");
}
function rb(w, f) {
  return w.j ? (f ? fz(w.j, w.k) : w.j) : w.k;
}
function take(cat, items, keyf, n) {
  var seen = ls("kb_seen") || {},
    sn = seen[cat] || [];
  var out = shuf(
    items.filter(function (x) {
      return sn.indexOf(keyf(x)) < 0;
    }),
  ).slice(0, n);
  if (out.length < n) {
    var rest = shuf(
      items.filter(function (x) {
        return out.indexOf(x) < 0;
      }),
    );
    out = out.concat(rest.slice(0, n - out.length));
    sn = [];
  }
  out.forEach(function (x) {
    sn.push(keyf(x));
  });
  seen[cat] = sn.slice(-800);
  ls("kb_seen", seen);
  return shuf(out);
}
function shuf(a) {
  a = a.slice();
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1)),
      t = a[i];
    a[i] = a[j];
    a[j] = t;
  }
  return a;
}

// ===== Tema terang atau gelap =====
function curTheme() {
  var t = S.theme || "auto";
  if (t === "auto")
    t = window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  return t;
}
function theme() {
  var t = curTheme();
  document.documentElement.setAttribute("data-theme", t);
  var m = $("tc");
  if (m) m.setAttribute("content", t === "dark" ? "#000000" : "#FFDDE8");
  var b = $("tg");
  if (b) {
    b.textContent = t === "dark" ? "☀️" : "🌙";
    b.setAttribute("title", t === "dark" ? "Ganti ke mode terang" : "Ganti ke mode gelap");
  }
}
$("tg").onclick = function () {
  S.theme = curTheme() === "dark" ? "light" : "dark";
  save();
  theme();
  if (SCR === "setting") setting();
};
(function () {
  if (!window.matchMedia) return;
  var mq = matchMedia("(prefers-color-scheme: dark)"),
    cb = function () {
      if ((S.theme || "auto") === "auto") theme();
    };
  if (mq.addEventListener) mq.addEventListener("change", cb);
  else if (mq.addListener) mq.addListener(cb);
})();
// ===== Navigasi antar halaman =====
var NAV = [],
  SCR = "",
  BK = false;
function goBack() {
  var pv = NAV.pop() || "home";
  BK = true;
  show(pv);
  BK = false;
}
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-back]");
  if (b && cur) goBack();
});
function show(v) {
  if (v === "home" || v === "login") NAV = [];
  else if (!BK && SCR && SCR !== v && SCR !== "login" && SCR !== "play") {
    NAV.push(SCR);
    if (NAV.length > 30) NAV.shift();
  }
  SCR = v;
  var sec = v === "hira" || v === "kata" ? "kana" : v === "thira" || v === "tkata" ? "kuis" : v;
  [
    "login",
    "home",
    "bab",
    "kana",
    "kuis",
    "kanji",
    "cerita",
    "pustaka",
    "nihongo",
    "kerja",
    "bunpou",
    "grup",
    "play",
    "setting",
  ].forEach(function (x) {
    $(x).classList.toggle("hide", x !== sec);
  });
  $("nav").classList.toggle("hide", v === "login" || v === "play");
  document.querySelectorAll(".nb[data-go]").forEach(function (b) {
    b.getAttribute("data-go") === v
      ? b.setAttribute("aria-current", "page")
      : b.removeAttribute("aria-current");
  });
  if (v === "home" || v === "bab") home();
  if (v === "hira" || v === "kata") kana(v);
  if (v === "thira" || v === "tkata") kuis(v === "thira" ? "hira" : "kata");
  if (v === "bunpou") bunpou();
  if (v === "grup") grup();
  if (v === "kanji") kanji();
  if (v === "cerita") cerita();
  if (v === "play") {
    if (GQ) {
      GQ = false;
      startG();
    } else start();
  }
  if (v === "setting") setting();
  window.scrollTo(0, 0);
}

// ===== Login, daftar, dan keluar =====
$("lb").onclick = function () {
  var n = $("u").value.trim(),
    p = $("p").value;
  if (!n) {
    $("lm").textContent = "Isi nama dulu.";
    return;
  }
  if (p.length < 4) {
    $("lm").textContent = "Password minimal 4 karakter.";
    return;
  }
  var u = users[n];
  if (!u) {
    users[n] = Object.assign(fresh(), { pin: p });
  } else if (u.pin !== p) {
    $("lm").textContent = "Password salah untuk nama ini.";
    return;
  }
  cur = n;
  ls("kb_cur", n);
  save();
  $("lm").textContent = "";
  $("p").value = "";
  $("p").type = "password";
  $("sp").checked = false;
  show("home");
};
$("sp").onchange = function () {
  $("p").type = this.checked ? "text" : "password";
};
$("out").onclick = function () {
  cloudPush();
  cur = null;
  ls("kb_cur", null);
  show("login");
};
document.addEventListener("click", function (e) {
  var g = e.target.closest("[data-go]");
  if (g && cur) show(g.getAttribute("data-go"));
});

// ===== Home dan pemilihan bab =====
function pool() {
  return W.filter(function (w) {
    return S.ls.indexOf(w.l) > -1;
  });
}
function home() {
  var u = users[cur];
  $("hi").textContent = "こんにちは、" + cur + "さん";
  $("s1").textContent = u.best;
  $("s2").textContent = u.played;
  $("s3").textContent = u.total ? Math.round((u.right / u.total) * 100) + "%" : "0%";
  var c = {};
  W.forEach(function (w) {
    c[w.l] = (c[w.l] || 0) + 1;
  });
  $("hl").innerHTML = Object.keys(D)
    .map(function (l) {
      var on = S.ls.indexOf(+l) > -1;
      return (
        '<button class="bab' +
        (on ? " on" : "") +
        '" data-l="' +
        l +
        '" aria-pressed="' +
        on +
        '"><b>Bab ' +
        l +
        "</b><span>" +
        c[l] +
        " kotoba</span></button>"
      );
    })
    .join("");
  var h = (u.h || []).slice(-5).reverse();
  $("hh").innerHTML = h.length
    ? h
        .map(function (x) {
          return (
            '<div style="padding:6px 0;border-bottom:1px solid var(--line)"><div class="row"><span>' +
            new Date(x.d).toLocaleString("id-ID", {
              day: "numeric",
              month: "short",
              hour: "2-digit",
              minute: "2-digit",
            }) +
            "</span><b>" +
            x.s +
            " / " +
            x.n +
            " (" +
            Math.round((x.s / x.n) * 100) +
            "%)</b></div>" +
            (x.l ? '<div style="color:var(--mute);font-size:14px">' + x.l + "</div>" : "") +
            (x.w && x.w.length
              ? '<button class="chip" style="margin-top:6px;font-weight:700" data-hw="' +
                x.d +
                '">Perlihatkan salah (' +
                x.w.length +
                ')</button><div class="hide" id="hw' +
                x.d +
                '"></div>'
              : x.w
                ? '<div style="color:var(--ok);font-size:14px">Semua jawaban benar 🎉</div>'
                : x.s < x.n
                  ? '<div style="color:var(--mute);font-size:14px">Detail salah tidak tersimpan pada riwayat lama.</div>'
                  : "") +
            "</div>"
          );
        })
        .join("")
    : '<span style="color:var(--mute)">Belum ada riwayat. Tekan Play untuk mulai.</span>';
  $("acc").textContent = "Skor dan riwayat tersimpan di browser ini";
  var t = pool().length * (S.dir === "jp" || S.dir === "id" ? 1 : 2);
  $("nq").value = S.n;
  $("hs").textContent = pool().length + " kotoba · " + t + " soal tersedia";
  $("hq").innerHTML = [5, 10, 20, 50, "Semua"]
    .map(function (n) {
      var v = n === "Semua" ? t : n;
      return (
        '<button class="chip' +
        (S.n === v ? " on" : "") +
        '" data-n="' +
        v +
        '">' +
        (n === "Semua" ? "Semua (" + t + ")" : n + " soal") +
        "</button>"
      );
    })
    .join("");
}
document.addEventListener("click", function (e) {
  var b = e.target.closest(".bab");
  if (b) {
    var l = +b.getAttribute("data-l"),
      i = S.ls.indexOf(l);
    if (i > -1) {
      if (S.ls.length > 1) S.ls.splice(i, 1);
    } else S.ls.push(l);
    save();
    home();
    return;
  }
  var q = e.target.closest("[data-n]");
  if (q) {
    S.n = +q.getAttribute("data-n");
    save();
    home();
  }
});
$("ha").onclick = function () {
  S.ls = Object.keys(D).map(Number);
  save();
  home();
};
$("nq").oninput = function () {
  var v = parseInt(this.value, 10);
  if (v > 0) {
    S.n = Math.min(v, 500);
    save();
    Array.prototype.forEach.call($("hq").children, function (x) {
      x.classList.toggle("on", +x.getAttribute("data-n") === S.n);
    });
  }
};
(function () {
  var p = document.createElement("div");
  p.className = "petals";
  p.setAttribute("aria-hidden", "true");
  for (var i = 0; i < 26; i++) {
    var x = document.createElement("span");
    x.style.left = Math.random() * 100 + "%";
    x.style.setProperty("--y", Math.random() * 100 + "%");
    var z = 9 + Math.random() * 10;
    x.style.width = z + "px";
    x.style.height = z * 1.2 + "px";
    x.style.animationDuration = 9 + Math.random() * 8 + "s";
    x.style.animationDelay = -Math.random() * 12 + "s";
    p.appendChild(x);
  }
  document.body.appendChild(p);
})();

// ===== Kuis kosakata (permainan utama) =====
var Q = [],
  qi = 0,
  sc = 0,
  lock = false,
  wr = [],
  GM = false,
  GQ = false,
  GP = "";
function start() {
  GM = false;
  var pool = W.filter(function (w) {
    return S.ls.indexOf(w.l) > -1;
  });
  if (pool.length < 4) {
    S.ls = [1, 2, 3, 4, 5];
    save();
    pool = W;
  }
  var it = [];
  pool.forEach(function (w) {
    if (S.dir !== "id") it.push(Object.assign({}, w, { dir: "jp" }));
    if (S.dir !== "jp") it.push(Object.assign({}, w, { dir: "id" }));
  });
  Q = take(
    "v",
    it,
    function (w) {
      return w.k + w.m + w.dir;
    },
    S.n,
  );
  qi = 0;
  sc = 0;
  wr = [];
  $("pq").classList.remove("hide");
  $("pr").classList.add("hide");
  ask();
}
function ask() {
  lock = false;
  if (GM) return askG(Q[qi]);
  var w = Q[qi],
    pool = W.filter(function (x) {
      return S.ls.indexOf(x.l) > -1 && x.m !== w.m && !(x.k === w.k && x.j === w.j);
    });
  var opts = shuf(trap(w, pool, 4).concat([w]));
  $("pn").textContent = "Soal " + (qi + 1) + " dari " + Q.length;
  $("ps").textContent = "Skor " + sc;
  $("pb").style.width = (qi / Q.length) * 100 + "%";
  $("fb").textContent = "";
  $("nx").classList.add("hide");
  var jp = w.dir === "jp";
  $("qt").innerHTML =
    '<div class="big' +
    (jp ? "" : " id") +
    '">' +
    (jp ? rb(w, S.furi) : w.m) +
    '</div><div style="color:var(--mute)">' +
    (jp ? "Apa artinya?" : "Mana kata Jepangnya?") +
    "</div>";
  var box = $("qo");
  box.innerHTML = "";
  opts.forEach(function (o) {
    var b = document.createElement("button");
    b.className = "opt" + (jp ? "" : " jp");
    b.innerHTML = jp ? o.m : rb(o, S.furi);
    b.setAttribute("data-ok", o === w ? "1" : "0");
    b.onclick = function () {
      pick(b, o === w, w);
    };
    box.appendChild(b);
  });
}
var AC;
function snd(ok) {
  if (!S.snd) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    var t = AC.currentTime;
    (ok
      ? [
          [660, 0],
          [880, 0.12],
        ]
      : [
          [220, 0],
          [165, 0.14],
        ]
    ).forEach(function (n) {
      var o = AC.createOscillator(),
        g = AC.createGain(),
        a = t + n[1];
      o.type = ok ? "sine" : "sawtooth";
      o.frequency.value = n[0];
      g.gain.setValueAtTime(0.0001, a);
      g.gain.exponentialRampToValueAtTime(0.2, a + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, a + 0.2);
      o.connect(g);
      g.connect(AC.destination);
      o.start(a);
      o.stop(a + 0.22);
    });
  } catch (e) {}
}
function pick(b, ok, w) {
  if (lock) return;
  lock = true;
  snd(ok);
  var all = $("qo").children;
  if (ok) {
    sc++;
    b.classList.add("ok");
    $("fb").style.color = "var(--ok)";
    $("fb").textContent = "Benar!";
  } else {
    wr.push(
      w.g
        ? {
            t: w.t,
            m: w.m,
            p: b.innerHTML,
            a: w.ans,
            y: w.ty,
            q: w.ty === 8 ? w.t : $("qt").innerHTML,
            f: w.ty === 2 ? gr(w.t) : "",
          }
        : { k: w.k, j: w.j, m: w.m, p: b.innerHTML, b: w.l },
    );
    b.classList.add("no");
    $("fb").style.color = "var(--no)";
    $("fb").innerHTML =
      "Kurang tepat. Jawabannya: " +
      (GM ? w.ans : (w.dir === "jp" ? w.m : rb(w, true)) + " (" + w.k + ")");
    Array.prototype.forEach.call(all, function (x) {
      if (x.getAttribute("data-ok") === "1") x.classList.add("ok");
    });
  }
  if (!GM && !ok) {
    var al = W.filter(function (x) {
      return x.k === w.k && x.j === w.j && x.m !== w.m;
    });
    if (al.length)
      $("fb").innerHTML +=
        '<br><span style="color:var(--mute);font-weight:400">Kata ini juga berarti: ' +
        al
          .map(function (x) {
            return x.m;
          })
          .join("; ") +
        "</span>";
  }
  $("ps").textContent = "Skor " + sc;
  $("nx").textContent = qi === Q.length - 1 ? "Lihat hasil" : "Lanjut";
  $("nx").classList.remove("hide");
  $("nx").focus();
}
$("nx").onclick = function () {
  qi++;
  qi < Q.length ? ask() : finish();
};
function finish() {
  var u = users[cur];
  u.played++;
  u.h = (u.h || []).concat([{ d: Date.now(), s: sc, n: Q.length, w: wr, l: lbl() }]).slice(-20);
  u.right += sc;
  u.total += Q.length;
  var pts = Math.round((sc / Q.length) * 100);
  if (pts > u.best) u.best = pts;
  save();
  $("pq").classList.add("hide");
  $("pr").classList.remove("hide");
  $("rs").textContent = sc + " / " + Q.length;
  $("sw").classList.toggle("hide", !wr.length);
  $("sw").textContent = "Perlihatkan salah (" + wr.length + ")";
  $("wl").classList.add("hide");
  $("wl").innerHTML = wl(wr);
  $("rt").textContent =
    pts >= 80
      ? "すごい！ Hebat sekali."
      : pts >= 50
        ? "いいですね。 Lumayan, ulangi lagi supaya makin hafal."
        : "がんばって！ Coba lagi, kosakatanya akan makin akrab.";
}
function lbl() {
  if (!GM)
    return (
      "Kosakata " +
      (S.ls.length > 8
        ? S.ls.length + " bab"
        : "Bab " +
          S.ls
            .slice()
            .sort(function (a, b) {
              return a - b;
            })
            .join(", ")) +
      " (" +
      { mix: "Campur", jp: "Jepang → Indonesia", id: "Indonesia → Jepang" }[S.dir || "mix"] +
      ")"
    );
  return GP === "J"
    ? "Kanji"
    : GP === "R"
      ? "Cerita Level " + (RS[RI].lv || 1) + ": " + RS[RI].n
      : GP === "G"
        ? "Pengelompokan kata kerja"
        : GP === "V"
          ? "Bentuk kata kerja"
          : GP === "K"
            ? "Tebak " + (KT === "hira" ? "Hiragana" : "Katakana")
            : "Partikel " + GP;
}
// ===== Pembuatan pilihan jawaban pengecoh yang mirip =====
function simw(a, b) {
  var s = 0,
    i,
    n = Math.min(a.k.length, b.k.length);
  if (a.k === b.k) s += 6;
  if (a.j && b.j)
    for (i = 0; i < a.j.length; i++)
      if (/[\u4E00-\u9FFF]/.test(a.j[i]) && b.j.indexOf(a.j[i]) > -1) s += 3;
  if (a.k.length === b.k.length) s++;
  for (i = 0; i < n && a.k[i] === b.k[i]; i++) s += 1.5;
  for (i = 1; i <= n && a.k[a.k.length - i] === b.k[b.k.length - i]; i++) s++;
  if (a.m.split(/[ ,]/)[0] === b.m.split(/[ ,]/)[0]) s += 2;
  return s + Math.random() * 2;
}
function trap(w, pool, n) {
  var seen = {},
    o = [];
  pool
    .map(function (x) {
      return [simw(w, x), x];
    })
    .sort(function (a, b) {
      return b[0] - a[0];
    })
    .forEach(function (p) {
      var x = p[1];
      if (o.length < n && !seen[x.m] && !seen["#" + x.k + x.j]) {
        seen[x.m] = 1;
        seen["#" + x.k + x.j] = 1;
        o.push(x);
      }
    });
  if (o.length < n)
    shuf(W).forEach(function (x) {
      if (
        o.length < n &&
        !seen[x.m] &&
        !seen["#" + x.k + x.j] &&
        x.m !== w.m &&
        !(x.k === w.k && x.j === w.j)
      ) {
        seen[x.m] = 1;
        seen["#" + x.k + x.j] = 1;
        o.push(x);
      }
    });
  return o;
}
var SKT =
  "大犬太 土士 千干 午牛 休体 待持 日目白 右石 末未 外夕 天夫 会合 間聞問門 語話読 時待 校交 週周 先光 友及 来束 作昨 小少 分今 力刀 字学 買貸 銀根 茶糸".split(
    " ",
  );
function simK(j) {
  var o = "";
  for (var i = 0; i < j.length; i++)
    SKT.forEach(function (g) {
      if (g.indexOf(j[i]) > -1) o += g.replace(j[i], "");
    });
  return o;
}
function fake(j) {
  for (var i = 0; i < j.length; i++)
    for (var g = 0; g < SKT.length; g++)
      if (SKT[g].indexOf(j[i]) > -1) {
        var a = SKT[g].replace(j[i], "");
        if (a) return j.slice(0, i) + a[0] + j.slice(i + 1);
      }
  return null;
}
var SIMH = [
    "さち",
    "ぬめ",
    "ねれわ",
    "はほま",
    "るろ",
    "あお",
    "いり",
    "きさ",
    "すむ",
    "のぬ",
    "ふう",
    "けは",
    "こに",
    "らう",
  ],
  SIMK = [
    "ンソ",
    "シツ",
    "ノメ",
    "クケ",
    "スヌ",
    "ウワ",
    "コユ",
    "ナメ",
    "チテ",
    "マム",
    "フワ",
    "ミシ",
    "ラフ",
    "ヲラ",
    "アマ",
    "ンノ",
  ],
  CONF = {
    は: ["が", "も", "を", "に"],
    が: ["は", "を", "に", "で"],
    を: ["が", "は", "に", "で"],
    に: ["で", "へ", "と", "を"],
    で: ["に", "へ", "を", "と"],
    へ: ["に", "で", "と", "を"],
    と: ["も", "に", "や", "で"],
    も: ["は", "と", "が", "や"],
    の: ["は", "を", "が", "に"],
    か: ["の", "は", "も", "よ"],
    から: ["まで", "より", "に", "で"],
    まで: ["から", "に", "で", "と"],
    や: ["と", "も", "か", "の"],
    よ: ["ね", "か", "の", "は"],
    ね: ["よ", "か", "な", "の"],
  };
function vwrong(v, f, fm) {
  var k = v.k,
    st = k.slice(0, -2),
    pre = k.slice(0, -3),
    c;
  if (f === "te")
    c = [st + "て", pre + "って", pre + "んで", pre + "いて", pre + "いで", pre + "して"];
  else if (f === "ta")
    c = [st + "た", pre + "った", pre + "んだ", pre + "いた", pre + "いだ", pre + "した"];
  else if (f === "nai")
    c = [
      st + "ない",
      pre + "わない",
      pre + "かない",
      pre + "らない",
      pre + "まない",
      pre + "さない",
      fm.dict + "ない",
    ];
  else c = [st + "る", pre + "う", pre + "く", pre + "す", pre + "む", pre + "ぶ", pre + "る"];
  var o = [];
  shuf(c).forEach(function (x) {
    if (x !== fm[f] && o.indexOf(x) < 0 && o.length < 4) o.push(x);
  });
  return o;
}
function wl(l) {
  return l.length
    ? l
        .map(function (x) {
          if (x.a !== undefined)
            return (
              '<div class="wr"><div>' +
              x.q +
              "</div>" +
              (x.f ? '<div style="color:var(--mute)">Kalimat lengkap: ' + x.f + "</div>" : "") +
              '<div style="color:var(--ok);font-weight:700">Jawaban benar: ' +
              x.a +
              "</div><div><span>Jawabanmu: " +
              x.p +
              "</span></div></div>"
            );
          return (
            '<div class="wr"><div style="font-size:20px">' +
            (x.t
              ? gr(x.t)
              : rb(x, true) +
                ' <span style="color:var(--mute);font-size:15px">(' +
                x.k +
                ")</span>") +
            (x.b
              ? ' <span style="color:var(--mute);font-size:14px">[Bab ' + x.b + "]</span>"
              : "") +
            " = <b>" +
            x.m +
            "</b></div><div><span>Jawabanmu: " +
            x.p +
            "</span></div></div>"
          );
        })
        .join("")
    : '<p style="color:var(--mute)">Tidak ada jawaban salah.</p>';
}
$("sw").onclick = function () {
  var l = $("wl");
  l.classList.toggle("hide");
  this.textContent =
    (l.classList.contains("hide") ? "Perlihatkan" : "Sembunyikan") + " salah (" + wr.length + ")";
};
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-hw]");
  if (!b) return;
  var d = b.getAttribute("data-hw"),
    el = $("hw" + d);
  if (!el.innerHTML) {
    var en = (users[cur].h || []).filter(function (x) {
      return String(x.d) === d;
    })[0];
    el.innerHTML = wl(en ? en.w : []);
  }
  el.classList.toggle("hide");
  b.textContent =
    (el.classList.contains("hide") ? "Perlihatkan" : "Sembunyikan") +
    b.textContent.replace(/^\S+/, "");
});
// ===== Hiragana dan Katakana (tabel dan kuis) =====
var KT = "hira",
  GN = ["Huruf dasar", "Dakuten dan handakuten", "Yoon (gabungan)", "Bunyi serapan"];
function KI(t) {
  var C = function (c) {
      return t === "hira"
        ? c
        : c.replace(/[ぁ-ゖ]/g, function (x) {
            return String.fromCharCode(x.charCodeAt(0) + 96);
          });
    },
    V = ["a", "i", "u", "e", "o"],
    R = ["", "k", "s", "t", "n", "h", "m", "y", "r", "w"],
    X = { si: "shi", ti: "chi", tu: "tsu", hu: "fu" },
    DX = { zi: "ji", di: "ji", du: "zu" },
    g = [[], [], []];
  [
    "あいうえお",
    "かきくけこ",
    "さしすせそ",
    "たちつてと",
    "なにぬねの",
    "はひふへほ",
    "まみむめも",
    "や　ゆ　よ",
    "らりるれろ",
    "わ　　　を",
  ].forEach(function (row, i) {
    for (var j = 0; j < 5; j++) {
      var r = R[i] + V[j];
      g[0].push(row[j] !== "　" ? [C(row[j]), X[r] || r] : null);
    }
  });
  g[0].push([C("ん"), "n"]);
  [
    ["がぎぐげご", "g"],
    ["ざじずぜぞ", "z"],
    ["だぢづでど", "d"],
    ["ばびぶべぼ", "b"],
    ["ぱぴぷぺぽ", "p"],
  ].forEach(function (d) {
    for (var j = 0; j < 5; j++) {
      var r = d[1] + V[j];
      g[1].push([C(d[0][j]), DX[r] || r]);
    }
  });
  [
    ["き", "ky"],
    ["し", "sh"],
    ["ち", "ch"],
    ["に", "ny"],
    ["ひ", "hy"],
    ["み", "my"],
    ["り", "ry"],
    ["ぎ", "gy"],
    ["じ", "j"],
    ["び", "by"],
    ["ぴ", "py"],
  ].forEach(function (y) {
    ["ゃ", "ゅ", "ょ"].forEach(function (z, j) {
      g[2].push([C(y[0] + z), y[1] + ["a", "u", "o"][j]]);
    });
  });
  if (t === "kata")
    g.push([
      ["ファ", "fa"],
      ["フィ", "fi"],
      ["フェ", "fe"],
      ["フォ", "fo"],
      ["ティ", "ti"],
      ["ディ", "di"],
      ["ウィ", "wi"],
      ["ウェ", "we"],
      ["ウォ", "wo"],
      ["シェ", "she"],
      ["ジェ", "je"],
      ["チェ", "che"],
    ]);
  return g;
}
function kitems() {
  var kp = kpool(),
    o = [];
  kp.forEach(function (x) {
    o.push({ g: 1, p: "K", ty: 6, a: x[0], r: x[1], rev: false, t: x[0], m: x[1] });
    if (
      kp.filter(function (y) {
        return y[1] === x[1];
      }).length === 1
    )
      o.push({ g: 1, p: "K", ty: 6, a: x[0], r: x[1], rev: true, t: x[0], m: x[1] });
  });
  return o;
}
function kpool() {
  var g = KI(KT),
    o = [];
  (S.kg || [0, 1, 2]).forEach(function (i) {
    if (g[i])
      g[i].forEach(function (x) {
        if (x) o.push(x);
      });
  });
  return o;
}
function kana(t) {
  KT = t;
  $("kt").innerHTML =
    t === "hira"
      ? 'Hiragana <span class="nw">ひらがな</span>'
      : 'Katakana <span class="nw">カタカナ</span>';
  var g = KI(t);
  $("kb").innerHTML = g
    .map(function (grp, i) {
      return (
        "<h3>" +
        GN[i] +
        '</h3><div class="kg' +
        (i === 2 ? " kg3" : "") +
        '">' +
        grp
          .map(function (x) {
            return x
              ? '<div class="kc"><b>' + x[0] + "</b><span>" + x[1] + "</span></div>"
              : '<div class="kc e"></div>';
          })
          .join("") +
        "</div>"
      );
    })
    .join("");
}
function kuis(t) {
  KT = t;
  $("kt2").innerHTML =
    t === "hira"
      ? 'Tebak Hiragana <span class="nw">ひらがな</span>'
      : 'Tebak Katakana <span class="nw">カタカナ</span>';
  var g = KI(t);
  S.kg = (S.kg || [0, 1, 2]).filter(function (i) {
    return g[i];
  });
  if (!S.kg.length) S.kg = [0];
  $("kg").innerHTML = g
    .map(function (_, i) {
      return (
        '<button class="chip' +
        (S.kg.indexOf(i) > -1 ? " on" : "") +
        '" data-kg="' +
        i +
        '">' +
        GN[i] +
        "</button>"
      );
    })
    .join("");
  var tot = kitems().length;
  S.kn = Math.min(S.kn || 10, tot);
  $("kq").max = tot;
  $("kq").value = S.kn;
  $("ks").textContent = "maks " + tot;
  $("kc").innerHTML = [10, 25, 50, "Semua"]
    .map(function (n) {
      var v = n === "Semua" ? tot : Math.min(n, tot);
      return (
        '<button class="chip' +
        (S.kn === v ? " on" : "") +
        '" data-kn="' +
        v +
        '">' +
        (n === "Semua" ? "Semua (" + tot + ")" : n + " soal") +
        "</button>"
      );
    })
    .join("");
}
$("kq").oninput = function () {
  var v = parseInt(this.value, 10);
  if (v > 0) {
    S.kn = Math.min(v, kitems().length);
    save();
    Array.prototype.forEach.call($("kc").children, function (x) {
      x.classList.toggle("on", +x.getAttribute("data-kn") === S.kn);
    });
  }
};
$("kp").onclick = function () {
  GP = "K";
  GQ = true;
  show("play");
};
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-kg]");
  if (b) {
    var i = +b.getAttribute("data-kg"),
      a = S.kg || [0, 1, 2],
      x = a.indexOf(i);
    if (x > -1) {
      if (a.length > 1) a.splice(x, 1);
    } else a.push(i);
    S.kg = a;
    save();
    kuis(KT);
    return;
  }
  b = e.target.closest("[data-kn]");
  if (b) {
    S.kn = +b.getAttribute("data-kn");
    save();
    kuis(KT);
  }
});
// ===== Latihan partikel (Bunpou Renshuu) =====
var GD = {
    は: [
      ["{私|わたし}*は*{学生|がくせい}です。", "Saya adalah mahasiswa."],
      ["これ*は*{辞書|じしょ}です。", "Ini adalah kamus."],
      ["ミラーさん*は*アメリカ{人|じん}です。", "Pak Miller adalah orang Amerika."],
      ["トイレ*は*どこですか。", "Di mana toilet?"],
      ["{今日|きょう}*は*{月曜日|げつようび}です。", "Hari ini hari Senin."],
      ["{私|わたし}*は*{毎朝|まいあさ}6{時|じ}に{起|お}きます。", "Saya bangun jam 6 setiap pagi."],
      ["{昨日|きのう}*は*{勉強|べんきょう}しませんでした。", "Kemarin saya tidak belajar."],
      ["{日本語|にほんご}*は*{難|むずか}しくないです。", "Bahasa Jepang tidak sulit."],
      ["{田中|たなか}さん*は*{会社|かいしゃ}にいません。", "Pak Tanaka tidak ada di kantor."],
      ["{京都|きょうと}*は*{静|しず}かな{町|まち}です。", "Kyoto adalah kota yang tenang."],
    ],
    が: [
      ["{雨|あめ}*が*{降|ふ}ります。", "Hujan turun."],
      ["{私|わたし}は{音楽|おんがく}*が*{好|す}きです。", "Saya suka musik."],
      ["{私|わたし}は{日本語|にほんご}*が*わかります。", "Saya mengerti bahasa Jepang."],
      ["{机|つくえ}の{上|うえ}に{本|ほん}*が*あります。", "Ada buku di atas meja."],
      ["{庭|にわ}に{犬|いぬ}*が*います。", "Ada anjing di halaman."],
      ["{私|わたし}は{車|くるま}*が*{欲|ほ}しいです。", "Saya ingin mobil."],
      ["{田中|たなか}さんは{料理|りょうり}*が*{上手|じょうず}です。", "Pak Tanaka pandai memasak."],
      ["{私|わたし}は{英語|えいご}*が*できます。", "Saya bisa bahasa Inggris."],
      ["{頭|あたま}*が*{痛|いた}いです。", "Kepala saya sakit."],
      ["だれ*が*{来|き}ましたか。", "Siapa yang datang?"],
    ],
    を: [
      ["{水|みず}*を*{飲|の}みます。", "Saya minum air."],
      ["{毎朝|まいあさ}パン*を*{食|た}べます。", "Saya makan roti setiap pagi."],
      ["{新聞|しんぶん}*を*{読|よ}みます。", "Saya membaca koran."],
      ["{写真|しゃしん}*を*{撮|と}ります。", "Saya memotret."],
      ["テレビ*を*{見|み}ます。", "Saya menonton televisi."],
      ["{手紙|てがみ}*を*{書|か}きます。", "Saya menulis surat."],
      ["{音楽|おんがく}*を*{聞|き}きます。", "Saya mendengarkan musik."],
      ["{友達|ともだち}にプレゼント*を*あげます。", "Saya memberi kado kepada teman."],
      ["{日本語|にほんご}*を*{勉強|べんきょう}します。", "Saya belajar bahasa Jepang."],
      ["{明日|あした}{会議|かいぎ}*を*します。", "Besok saya mengadakan rapat."],
    ],
    に: [
      ["{私|わたし}は{毎朝|まいあさ}6{時|じ}*に*{起|お}きます。", "Saya bangun jam 6 setiap pagi."],
      [
        "{日曜日|にちようび}*に*{京都|きょうと}へ{行|い}きます。",
        "Pada hari Minggu saya pergi ke Kyoto.",
      ],
      ["{庭|にわ}*に*{猫|ねこ}がいます。", "Ada kucing di halaman."],
      ["{友達|ともだち}*に*{手紙|てがみ}を{書|か}きます。", "Saya menulis surat untuk teman."],
      ["{田中|たなか}さん*に*{花|はな}をあげます。", "Saya memberi bunga kepada Pak Tanaka."],
      ["{先生|せんせい}*に*{本|ほん}を{借|か}ります。", "Saya meminjam buku dari guru."],
      ["{電車|でんしゃ}*に*{乗|の}ります。", "Saya naik kereta."],
      ["{東京|とうきょう}*に*{住|す}んでいます。", "Saya tinggal di Tokyo."],
      ["{椅子|いす}*に*{座|すわ}ります。", "Saya duduk di kursi."],
      [
        "2{月|がつ}*に*{日本|にほん}へ{来|き}ました。",
        "Saya datang ke Jepang pada bulan Februari.",
      ],
    ],
    で: [
      ["{図書館|としょかん}*で*{本|ほん}を{読|よ}みます。", "Saya membaca buku di perpustakaan."],
      [
        "{電車|でんしゃ}*で*{会社|かいしゃ}へ{行|い}きます。",
        "Saya pergi ke kantor dengan kereta.",
      ],
      ["{食堂|しょくどう}*で*{昼|ひる}ごはんを{食|た}べます。", "Saya makan siang di kantin."],
      ["はし*で*{食|た}べます。", "Saya makan dengan sumpit."],
      [
        "{日本語|にほんご}*で*{手紙|てがみ}を{書|か}きます。",
        "Saya menulis surat dalam bahasa Jepang.",
      ],
      ["{鉛筆|えんぴつ}*で*{名前|なまえ}を{書|か}きます。", "Saya menulis nama dengan pensil."],
      ["{駅|えき}*で*{友達|ともだち}に{会|あ}います。", "Saya bertemu teman di stasiun."],
      ["スーパー*で*{野菜|やさい}を{買|か}います。", "Saya membeli sayur di supermarket."],
      [
        "{自転車|じてんしゃ}*で*{学校|がっこう}へ{行|い}きます。",
        "Saya pergi ke sekolah dengan sepeda.",
      ],
      ["{全部|ぜんぶ}*で*1000{円|えん}です。", "Semuanya seribu yen."],
    ],
    の: [
      ["これは{私|わたし}*の*{本|ほん}です。", "Ini buku saya."],
      [
        "{私|わたし}は{日本語|にほんご}*の*{先生|せんせい}です。",
        "Saya adalah guru bahasa Jepang.",
      ],
      ["{机|つくえ}*の*{上|うえ}に{辞書|じしょ}があります。", "Ada kamus di atas meja."],
      ["{田中|たなか}さん*の*{車|くるま}は{大|おお}きいです。", "Mobil Pak Tanaka besar."],
      ["IMC*の*{社員|しゃいん}です。", "Saya karyawan IMC."],
      ["これは{日本|にほん}*の*お{土産|みやげ}です。", "Ini oleh-oleh dari Jepang."],
      ["{駅|えき}*の*{前|まえ}に{銀行|ぎんこう}があります。", "Ada bank di depan stasiun."],
      ["{姉|あね}*の*{名前|なまえ}は{花子|はなこ}です。", "Nama kakak perempuan saya Hanako."],
      ["{英語|えいご}*の*{本|ほん}を{買|か}いました。", "Saya membeli buku bahasa Inggris."],
      ["{日曜日|にちようび}*の*{朝|あさ}は{寝|ね}ます。", "Pada pagi hari Minggu saya tidur."],
    ],
    も: [
      ["{私|わたし}*も*{学生|がくせい}です。", "Saya juga mahasiswa."],
      ["ワットさん*も*{先生|せんせい}です。", "Pak Watt juga guru."],
      ["{私|わたし}は{紅茶|こうちゃ}*も*{飲|の}みます。", "Saya juga minum teh."],
      ["{日曜日|にちようび}*も*{働|はたら}きます。", "Saya juga bekerja pada hari Minggu."],
      ["{肉|にく}*も*{魚|さかな}*も*{食|た}べません。", "Saya tidak makan daging maupun ikan."],
      ["{今日|きょう}*も*{雨|あめ}です。", "Hari ini juga hujan."],
      [
        "{姉|あね}*も*{東京|とうきょう}に{住|す}んでいます。",
        "Kakak perempuan saya juga tinggal di Tokyo.",
      ],
      ["{映画|えいが}*も*{好|す}きです。", "Saya juga suka film."],
      ["どこ*も*{行|い}きません。", "Saya tidak pergi ke mana pun."],
      ["だれ*も*{来|き}ませんでした。", "Tidak ada seorang pun yang datang."],
    ],
    へ: [
      ["{学校|がっこう}*へ*{行|い}きます。", "Saya pergi ke sekolah."],
      ["{明日|あした}{京都|きょうと}*へ*{行|い}きます。", "Besok saya pergi ke Kyoto."],
      ["{日本|にほん}*へ*{来|き}ました。", "Saya datang ke Jepang."],
      ["うち*へ*{帰|かえ}ります。", "Saya pulang ke rumah."],
      ["{来週|らいしゅう}{大阪|おおさか}*へ*{行|い}きます。", "Minggu depan saya pergi ke Osaka."],
      ["どこ*へ*{行|い}きますか。", "Kamu pergi ke mana?"],
      ["{会社|かいしゃ}*へ*{電車|でんしゃ}で{行|い}きます。", "Saya pergi ke kantor naik kereta."],
      ["{郵便局|ゆうびんきょく}*へ*{行|い}きます。", "Saya pergi ke kantor pos."],
      [
        "{先週|せんしゅう}{東京|とうきょう}*へ*{行|い}きました。",
        "Minggu lalu saya pergi ke Tokyo.",
      ],
      ["{右|みぎ}*へ*{曲|ま}がってください。", "Tolong belok ke kanan."],
    ],
    と: [
      [
        "{家族|かぞく}*と*{日本|にほん}へ{来|き}ました。",
        "Saya datang ke Jepang bersama keluarga.",
      ],
      ["{友達|ともだち}*と*{映画|えいが}を{見|み}ます。", "Saya menonton film bersama teman."],
      ["{本|ほん}*と*ノートを{買|か}いました。", "Saya membeli buku dan buku tulis."],
      [
        "{田中|たなか}さん*と*{山田|やまだ}さんは{先生|せんせい}です。",
        "Pak Tanaka dan Pak Yamada adalah guru.",
      ],
      ["{彼女|かのじょ}*と*{会|あ}います。", "Saya bertemu dengan dia (perempuan)."],
      ["{先生|せんせい}*と*{話|はな}します。", "Saya berbicara dengan guru."],
      [
        "{月曜日|げつようび}*と*{水曜日|すいようび}に{勉強|べんきょう}します。",
        "Saya belajar pada hari Senin dan Rabu.",
      ],
      [
        "{父|ちち}*と*{母|はは}は{会社員|かいしゃいん}です。",
        "Ayah dan ibu saya adalah karyawan perusahaan.",
      ],
      [
        "{友達|ともだち}*と*{食堂|しょくどう}で{昼|ひる}ごはんを{食|た}べます。",
        "Saya makan siang di kantin bersama teman.",
      ],
      [
        "{妹|いもうと}*と*{公園|こうえん}へ{行|い}きます。",
        "Saya pergi ke taman bersama adik perempuan.",
      ],
    ],
    か: [
      ["{学生|がくせい}です*か*。", "Apakah Anda mahasiswa?"],
      ["これは{辞書|じしょ}です*か*。", "Apakah ini kamus?"],
      ["{今|いま}{何時|なんじ}です*か*。", "Sekarang jam berapa?"],
      ["{明日|あした}{学校|がっこう}へ{行|い}きます*か*。", "Apakah besok kamu pergi ke sekolah?"],
      ["コーヒー*か*{紅茶|こうちゃ}を{飲|の}みます。", "Saya minum kopi atau teh."],
      ["{昨日|きのう}{勉強|べんきょう}しました*か*。", "Apakah kemarin kamu belajar?"],
      [
        "ミラーさんは{先生|せんせい}です*か*、{学生|がくせい}です*か*。",
        "Apakah Pak Miller guru atau mahasiswa?",
      ],
      ["トイレはどこです*か*。", "Di mana toilet?"],
      ["{誕生日|たんじょうび}はいつです*か*。", "Kapan hari ulang tahunmu?"],
      ["{一緒|いっしょ}に{行|い}きません*か*。", "Maukah kamu pergi bersama?"],
    ],
    から: [
      ["9{時|じ}*から*{仕事|しごと}です。", "Pekerjaan mulai jam 9."],
      [
        "{月曜日|げつようび}*から*{金曜日|きんようび}まで{働|はたら}きます。",
        "Saya bekerja dari Senin sampai Jumat.",
      ],
      ["{私|わたし}はインドネシア*から*{来|き}ました。", "Saya datang dari Indonesia."],
      [
        "{東京|とうきょう}*から*{大阪|おおさか}まで{新幹線|しんかんせん}で{行|い}きます。",
        "Saya pergi dari Tokyo ke Osaka naik Shinkansen.",
      ],
      ["{銀行|ぎんこう}は{午前|ごぜん}9{時|じ}*から*です。", "Bank buka mulai jam 9 pagi."],
      [
        "{勉強|べんきょう}が{好|す}きです*から*、{毎日|まいにち}{勉強|べんきょう}します。",
        "Karena suka belajar, saya belajar setiap hari.",
      ],
      ["{忙|いそが}しい*から*、{行|い}きません。", "Karena sibuk, saya tidak pergi."],
      ["{安|やす}いです*から*、{買|か}います。", "Karena murah, saya membeli."],
      ["{友達|ともだち}*から*{手紙|てがみ}をもらいました。", "Saya menerima surat dari teman."],
      ["{会議|かいぎ}は{何時|なんじ}*から*ですか。", "Rapat mulai jam berapa?"],
    ],
    まで: [
      ["{図書館|としょかん}は5{時|じ}*まで*です。", "Perpustakaan buka sampai jam 5."],
      [
        "{月曜日|げつようび}から{金曜日|きんようび}*まで*{働|はたら}きます。",
        "Saya bekerja dari Senin sampai Jumat.",
      ],
      [
        "{大阪|おおさか}*まで*{電車|でんしゃ}で{行|い}きます。",
        "Saya pergi sampai Osaka naik kereta.",
      ],
      [
        "{昨日|きのう}は{夜|よる}12{時|じ}*まで*{勉強|べんきょう}しました。",
        "Kemarin saya belajar sampai jam 12 malam.",
      ],
      ["{駅|えき}*まで*{歩|ある}いて{行|い}きます。", "Saya berjalan kaki sampai stasiun."],
      ["{銀行|ぎんこう}は{午後|ごご}3{時|じ}*まで*です。", "Bank buka sampai jam 3 sore."],
      ["{休|やす}みは{日曜日|にちようび}*まで*です。", "Liburan sampai hari Minggu."],
      ["{朝|あさ}から{晩|ばん}*まで*{働|はたら}きます。", "Saya bekerja dari pagi sampai malam."],
      ["{会議|かいぎ}は{何時|なんじ}*まで*ですか。", "Rapat sampai jam berapa?"],
      ["{東京|とうきょう}{駅|えき}*まで*いくらですか。", "Sampai Stasiun Tokyo berapa ongkosnya?"],
    ],
    や: [
      [
        "{机|つくえ}の{上|うえ}に{本|ほん}*や*{辞書|じしょ}があります。",
        "Di atas meja ada buku, kamus, dan lain-lain.",
      ],
      [
        "{公園|こうえん}に{犬|いぬ}*や*{猫|ねこ}がいます。",
        "Di taman ada anjing, kucing, dan lain-lain.",
      ],
      ["りんご*や*みかんが{好|す}きです。", "Saya suka apel, jeruk, dan lain-lain."],
      [
        "{店|みせ}で{肉|にく}*や*{野菜|やさい}を{買|か}いました。",
        "Di toko saya membeli daging, sayur, dan lain-lain.",
      ],
      [
        "{冷蔵庫|れいぞうこ}に{卵|たまご}*や*{牛乳|ぎゅうにゅう}があります。",
        "Di kulkas ada telur, susu, dan lain-lain.",
      ],
      [
        "{日本|にほん}で{京都|きょうと}*や*{奈良|なら}へ{行|い}きました。",
        "Di Jepang saya pergi ke Kyoto, Nara, dan lain-lain.",
      ],
      [
        "かばんの{中|なか}に{手帳|てちょう}*や*{鍵|かぎ}があります。",
        "Di dalam tas ada agenda, kunci, dan lain-lain.",
      ],
      [
        "{土曜日|どようび}*や*{日曜日|にちようび}は{休|やす}みです。",
        "Sabtu, Minggu, dan lain-lain libur.",
      ],
      [
        "{駅|えき}の{前|まえ}に{銀行|ぎんこう}*や*{郵便局|ゆうびんきょく}があります。",
        "Di depan stasiun ada bank, kantor pos, dan lain-lain.",
      ],
      ["{紅茶|こうちゃ}*や*ジュースを{飲|の}みます。", "Saya minum teh, jus, dan lain-lain."],
    ],
    よ: [
      ["{明日|あした}は{休|やす}みです*よ*。", "Besok libur, lho."],
      ["{駅|えき}はあそこです*よ*。", "Stasiun ada di sana, lho."],
      ["この{本|ほん}はおもしろいです*よ*。", "Buku ini menarik, lho."],
      ["{今日|きょう}は{寒|さむ}いです*よ*。", "Hari ini dingin, lho."],
      ["あのレストランはおいしいです*よ*。", "Restoran itu enak, lho."],
      [
        "{田中|たなか}さんは{会社|かいしゃ}にいません*よ*。",
        "Pak Tanaka tidak ada di kantor, lho.",
      ],
      ["{電車|でんしゃ}は{速|はや}いです*よ*。", "Kereta itu cepat, lho."],
      ["この{傘|かさ}は{私|わたし}のです*よ*。", "Payung ini punya saya, lho."],
      ["{会議|かいぎ}は3{時|じ}からです*よ*。", "Rapat mulai jam 3, lho."],
      ["{富士山|ふじさん}は{高|たか}いです*よ*。", "Gunung Fuji tinggi, lho."],
    ],
    ね: [
      ["いい{天気|てんき}です*ね*。", "Cuacanya bagus ya."],
      ["{今日|きょう}は{暑|あつ}いです*ね*。", "Hari ini panas ya."],
      ["すてきな{傘|かさ}です*ね*。", "Payung yang bagus ya."],
      ["{日本語|にほんご}は{難|むずか}しいです*ね*。", "Bahasa Jepang sulit ya."],
      ["{毎日|まいにち}{大変|たいへん}です*ね*。", "Setiap hari berat ya."],
      ["{明日|あした}は{休|やす}みです*ね*。", "Besok libur ya."],
      ["{京都|きょうと}は{静|しず}かです*ね*。", "Kyoto tenang ya."],
      ["{田中|たなか}さんは{親切|しんせつ}です*ね*。", "Pak Tanaka baik hati ya."],
      ["この{料理|りょうり}はおいしいです*ね*。", "Masakan ini enak ya."],
      ["{新|あたら}しい{車|くるま}です*ね*。", "Mobil baru ya."],
    ],
  },
  GR = {
    は: "wa",
    が: "ga",
    を: "wo",
    に: "ni",
    で: "de",
    の: "no",
    も: "mo",
    へ: "e",
    と: "to",
    か: "ka",
    から: "kara",
    まで: "made",
    や: "ya",
    よ: "yo",
    ね: "ne",
  };
function gr(t) {
  return t
    .replace(/\*(.+?)\*/g, "<mark>$1</mark>")
    .replace(/\{(.+?)\|(.+?)\}/g, function (m, a, b) {
      return S.furi ? rr(a, b) : a;
    });
}
function bunpou() {
  S.gn = S.gn || 10;
  $("gq").value = S.gn;
  $("gh").innerHTML = [5, 10, 15, 25]
    .map(function (n) {
      return (
        '<button class="chip' +
        (S.gn === n ? " on" : "") +
        '" data-gn="' +
        n +
        '">' +
        n +
        " soal</button>"
      );
    })
    .join("");
  $("bp").innerHTML =
    Object.keys(GD)
      .map(function (k) {
        return (
          '<button class="bab" data-p="' +
          k +
          '"><b style="font-size:26px">' +
          k +
          "</b><span>" +
          GR[k] +
          " · " +
          GD[k].length * 3 +
          " soal</span></button>"
        );
      })
      .join("") +
    '<button class="bab" data-p="V"><b style="font-size:20px">動詞</b><span>bentuk kata kerja</span></button>';
}
$("gq").oninput = function () {
  var v = parseInt(this.value, 10);
  if (v > 0) {
    S.gn = Math.min(v, 25);
    save();
    Array.prototype.forEach.call($("gh").children, function (x) {
      x.classList.toggle("on", +x.getAttribute("data-gn") === S.gn);
    });
  }
};
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-gn]");
  if (b) {
    S.gn = +b.getAttribute("data-gn");
    save();
    bunpou();
  }
});
// ===== Kata kerja: kelompok dan bentuk =====
var VC = null,
  EXV = [
    "おねがいします",
    "よろしくおねがいします",
    "しつれいします",
    "そろそろしつれいします",
    "どうもありがとうございます",
    "おめでとうございます",
    "いただきます",
    "いってきます",
    "これからおせわになります",
    "こちらこそよろしくおねがいします",
    "のどがかわきます",
    "おなかがすきます",
    "いらっしゃいます",
    "~でございます",
  ],
  IIi = ["みます", "います", "あびます", "できます", "かります", "おります", "たります"],
  SH = [
    "はなします",
    "かします",
    "だします",
    "なくします",
    "おします",
    "なおします",
    "まわします",
    "かえします",
    "おろします",
  ],
  UU = { い: "う", き: "く", ぎ: "ぐ", し: "す", ち: "つ", に: "ぬ", び: "ぶ", み: "む", り: "る" },
  AA = { い: "わ", き: "か", ぎ: "が", し: "さ", ち: "た", に: "な", び: "ば", み: "ま", り: "ら" };
function vg(w) {
  var k = w.k;
  if (k.slice(-2) !== "ます" || EXV.indexOf(k) > -1) return 0;
  if (k === "きます") return w.j === "来ます" ? 3 : 2;
  if (k === "おきます") return w.j === "起きます" ? 2 : 1;
  if (/(もって|つれて)きます$/.test(k)) return 3;
  if (k.slice(-3) === "します" && SH.indexOf(k) < 0) return 3;
  return "えけせてねへめれげぜでべぺ".indexOf(k.charAt(k.length - 3)) > -1 || IIi.indexOf(k) > -1
    ? 2
    : 1;
}
function verbs() {
  if (!VC) {
    var sn = {};
    VC = [];
    W.forEach(function (w) {
      var g = vg(w),
        key = w.k + "|" + (w.j || "");
      if (g && !sn[key]) {
        sn[key] = 1;
        VC.push({ k: w.k, j: w.j, m: w.m, g: g });
      }
    });
  }
  return VC;
}
function mk(v) {
  return v.j ? "{" + v.j + "|" + v.k + "}" : v.k;
}
function forms(v) {
  var k = v.k,
    st = k.slice(0, -2),
    pre,
    te,
    nai,
    dic;
  if (v.g === 2) {
    te = st + "て";
    nai = st + "ない";
    dic = st + "る";
  } else if (v.g === 3) {
    pre = k.slice(0, -3);
    if (k.slice(-3) === "きます") {
      te = pre + "きて";
      nai = pre + "こない";
      dic = pre + "くる";
    } else {
      te = pre + "して";
      nai = pre + "しない";
      dic = pre + "する";
    }
  } else {
    var l = st.slice(-1);
    pre = st.slice(0, -1);
    dic = pre + UU[l];
    nai = k === "あります" ? "ない" : pre + AA[l] + "ない";
    te = /いきます$/.test(k)
      ? pre + "って"
      : l === "い" || l === "ち" || l === "り"
        ? pre + "って"
        : l === "み" || l === "び" || l === "に"
          ? pre + "んで"
          : l === "き"
            ? pre + "いて"
            : l === "ぎ"
              ? pre + "いで"
              : pre + "して";
  }
  var ta = te.slice(0, -1) + (te.slice(-1) === "で" ? "だ" : "た");
  if (v.g === 3 && k.slice(-3) === "きます") ta = pre + "きた";
  return { te: te, nai: nai, ta: ta, dict: dic };
}
function kw0(x) {
  return x.j && x.k.length <= 8 && !/[~\[\]、。…]/.test(x.j + x.k);
}
// ===== Cerita (読解) =====
var RI = 0,
  RS = [
    {
      n: "Perkenalan",
      t: "{私|わたし}はミラーです。アメリカ{人|じん}です。IMCの{社員|しゃいん}です。{毎朝|まいあさ}7{時|じ}に{起|お}きます。8{時|じ}に{会社|かいしゃ}へ{行|い}きます。{会社|かいしゃ}は9{時|じ}から5{時|じ}までです。",
      q: [
        ["Pak Miller berasal dari mana?", ["Inggris", "Amerika Serikat", "Jepang", "India"], 1],
        ["Jam berapa Pak Miller bangun?", ["Jam 5", "Jam 7", "Jam 8", "Jam 9"], 1],
        ["Jam kerja di kantor sampai jam berapa?", ["Jam 5", "Jam 7", "Jam 8", "Jam 9"], 0],
      ],
    },
    {
      n: "Pergi ke Osaka",
      t: "{昨日|きのう}、{友達|ともだち}と{大阪|おおさか}へ{行|い}きました。{電車|でんしゃ}で{行|い}きました。{大阪城|おおさかじょう}を{見|み}ました。それから、レストランで{昼|ひる}ごはんを{食|た}べました。{晩|ばん}ごはんは{家|うち}で{食|た}べました。",
      q: [
        ["Pergi ke Osaka naik apa?", ["Pesawat", "Kereta", "Bus", "Sepeda"], 1],
        ["Pergi dengan siapa?", ["Sendirian", "Keluarga", "Teman", "Guru"], 2],
        ["Di mana makan malam?", ["Di restoran", "Di rumah", "Di kantin", "Di Osaka"], 1],
      ],
    },
    {
      n: "Keluarga",
      t: "{私|わたし}の{家族|かぞく}は4{人|にん}です。{父|ちち}と{母|はは}と{姉|あね}と{私|わたし}です。{父|ちち}は{先生|せんせい}です。{母|はは}は{会社員|かいしゃいん}です。{姉|あね}は{大学|だいがく}で{勉強|べんきょう}します。",
      q: [
        ["Berapa anggota keluarganya?", ["3 orang", "4 orang", "5 orang", "2 orang"], 1],
        ["Apa pekerjaan ayahnya?", ["Guru", "Karyawan perusahaan", "Mahasiswa", "Dokter"], 0],
        [
          "Kakak perempuannya belajar di mana?",
          ["Di sekolah", "Di perusahaan", "Di universitas", "Di perpustakaan"],
          2,
        ],
      ],
    },
    {
      n: "Hari Minggu",
      t: "{日曜日|にちようび}は{公園|こうえん}へ{行|い}きました。いい{天気|てんき}でした。でも、{少|すこ}し{寒|さむ}かったです。{公園|こうえん}で{写真|しゃしん}を{撮|と}りました。",
      q: [
        ["Hari Minggu pergi ke mana?", ["Taman", "Toserba", "Stasiun", "Sekolah"], 0],
        [
          "Bagaimana cuacanya?",
          ["Bagus dan panas", "Bagus tetapi sedikit dingin", "Hujan", "Mendung"],
          1,
        ],
        [
          "Apa yang dilakukan di sana?",
          ["Menulis surat", "Menonton film", "Memotret", "Membaca buku"],
          2,
        ],
      ],
    },
    {
      n: "Belanja",
      t: "{今日|きょう}はデパートへ{行|い}きました。デパートは{駅|えき}の{前|まえ}にあります。シャツを{買|か}いました。シャツは{安|やす}かったです。でも、くつは{高|たか}かったです。それで、くつは{買|か}いませんでした。",
      q: [
        [
          "Toserba ada di mana?",
          ["Di depan stasiun", "Di dalam stasiun", "Di sebelah bank", "Di depan sekolah"],
          0,
        ],
        ["Apa yang dibeli?", ["Sepatu", "Kemeja", "Topi", "Tas"], 1],
        [
          "Mengapa sepatu tidak dibeli?",
          ["Karena jelek", "Karena sepatunya mahal", "Karena kemejanya murah", "Karena toko tutup"],
          1,
        ],
      ],
    },
  ];
RS[0].q.push(
  ["Di perusahaan apa Pak Miller bekerja?", ["IMC", "AKC", "Sakura", "Fuji"], 0],
  ["Jam berapa Pak Miller berangkat ke kantor?", ["Jam 7", "Jam 8", "Jam 9", "Jam 5"], 1],
  ["Kantor mulai bekerja jam berapa?", ["Jam 5", "Jam 7", "Jam 8", "Jam 9"], 3],
);
RS[1].q.push(
  ["Kapan pergi ke Osaka?", ["Kemarin", "Hari ini", "Besok", "Minggu lalu"], 0],
  [
    "Apa yang dilihat di Osaka?",
    ["Kuil Kinkakuji", "Benteng Osaka", "Gunung Fuji", "Taman Nara"],
    1,
  ],
  ["Makan siang di mana?", ["Di rumah", "Di restoran", "Di kantin", "Di stasiun"], 1],
);
RS[2].q.push(
  [
    "Siapa saja anggota keluarganya?",
    [
      "Ayah, ibu, kakak perempuan, dan penulis",
      "Ayah, ibu, kakak laki-laki, dan penulis",
      "Ayah, ibu, adik perempuan, dan penulis",
      "Kakek, nenek, ayah, dan penulis",
    ],
    0,
  ],
  ["Apa pekerjaan ibunya?", ["Guru", "Karyawan perusahaan", "Dokter", "Mahasiswa"], 1],
  ["Siapa yang belajar di universitas?", ["Ayah", "Ibu", "Kakak perempuan", "Penulis"], 2],
);
RS[3].q.push(
  ["Kapan cerita ini terjadi?", ["Hari Sabtu", "Hari Minggu", "Hari Senin", "Hari Jumat"], 1],
  [
    "Mengapa penulis merasa kurang nyaman?",
    ["Terlalu panas", "Sedikit dingin", "Hujan deras", "Lapar"],
    1,
  ],
  ["Foto diambil di mana?", ["Di taman", "Di rumah", "Di sekolah", "Di toko"], 0],
);
RS[4].q.push(
  ["Kapan pergi ke toserba?", ["Hari ini", "Kemarin", "Besok", "Minggu depan"], 0],
  ["Bagaimana harga kemeja?", ["Mahal", "Murah", "Gratis", "Tidak disebutkan"], 1],
  ["Bagaimana harga sepatu?", ["Murah", "Mahal", "Sama dengan kemeja", "Gratis"], 1],
);
RS.push(
  {
    lv: 2,
    n: "Hari libur Tanaka",
    t: "{田中|たなか}さんは{会社員|かいしゃいん}です。{毎日|まいにち}{電車|でんしゃ}で{会社|かいしゃ}へ{行|い}きます。{土曜日|どようび}と{日曜日|にちようび}は{会社|かいしゃ}が{休|やす}みです。{先週|せんしゅう}の{日曜日|にちようび}、{田中|たなか}さんは{家族|かぞく}と{京都|きょうと}へ{行|い}きました。{京都|きょうと}は{静|しず}かな{町|まち}です。お{寺|てら}や{神社|じんじゃ}がたくさんあります。{昼|ひる}ごはんは{友達|ともだち}の{店|みせ}で{食|た}べました。{料理|りょうり}はおいしかったです。{晩|ばん}は{新幹線|しんかんせん}で{帰|かえ}りました。",
    q: [
      ["Tanaka-san berangkat ke kantor naik apa?", ["Bus", "Kereta", "Mobil", "Sepeda"], 1],
      [
        "Kapan kantornya libur?",
        ["Sabtu dan Minggu", "Senin dan Selasa", "Hanya hari Minggu", "Jumat dan Sabtu"],
        0,
      ],
      ["Dengan siapa ia pergi ke Kyoto?", ["Teman", "Keluarga", "Sendirian", "Rekan kerja"], 1],
      [
        "Bagaimana kota Kyoto digambarkan?",
        ["Ramai dan modern", "Tenang dan banyak kuil", "Panas dan luas", "Kecil tanpa kuil"],
        1,
      ],
      [
        "Makan siang di mana?",
        ["Di restoran hotel", "Di toko milik teman", "Di kantin kantor", "Di rumah"],
        1,
      ],
      ["Pulang naik apa?", ["Kereta biasa", "Bus", "Shinkansen", "Pesawat"], 2],
    ],
  },
  {
    lv: 2,
    n: "Belajar bahasa Jepang",
    t: "{私|わたし}はインドネシア{人|じん}です。{去年|きょねん}{日本|にほん}へ{来|き}ました。{今|いま}、{大学|だいがく}で{日本語|にほんご}を{勉強|べんきょう}します。{毎朝|まいあさ}6{時|じ}に{起|お}きて、{図書館|としょかん}で{漢字|かんじ}を{勉強|べんきょう}します。{漢字|かんじ}は{難|むずか}しいですが、おもしろいです。{午後|ごご}は{友達|ともだち}と{日本語|にほんご}で{話|はな}します。{土曜日|どようび}はレストランでアルバイトをします。{来年|らいねん}は{国|くに}へ{帰|かえ}ります。",
    q: [
      [
        "Sejak kapan penulis berada di Jepang?",
        ["Sejak tahun lalu", "Sejak bulan lalu", "Sejak tahun depan", "Sejak kemarin"],
        0,
      ],
      [
        "Apa yang dipelajari penulis di perpustakaan?",
        ["Bahasa Inggris", "Kanji", "Matematika", "Memasak"],
        1,
      ],
      [
        "Bagaimana penulis menilai kanji?",
        [
          "Mudah dan membosankan",
          "Sulit tetapi menarik",
          "Mudah dan menarik",
          "Sulit dan tidak suka",
        ],
        1,
      ],
      [
        "Dengan bahasa apa ia bicara dengan teman?",
        ["Bahasa Indonesia", "Bahasa Inggris", "Bahasa Jepang", "Bahasa Cina"],
        2,
      ],
      [
        "Apa yang dilakukan hari Sabtu?",
        [
          "Belajar di universitas",
          "Kerja paruh waktu di restoran",
          "Pergi ke Kyoto",
          "Tidur di rumah",
        ],
        1,
      ],
      [
        "Kapan penulis pulang ke negaranya?",
        ["Tahun depan", "Tahun ini", "Besok", "Bulan lalu"],
        0,
      ],
    ],
  },
  {
    lv: 2,
    n: "Di toserba",
    t: "{昨日|きのう}、{私|わたし}は{友達|ともだち}とデパートへ{行|い}きました。デパートは{駅|えき}の{前|まえ}にあります。{地下|ちか}に{食|た}べ{物|もの}の{売|う}り{場|ば}があります。{私|わたし}はそこで{果物|くだもの}を{買|か}いました。りんごは1つ150{円|えん}でした。{友達|ともだち}は{肉|にく}と{魚|さかな}を{買|か}いました。それから、3{階|かい}で{靴|くつ}を{見|み}ました。{靴|くつ}は{高|たか}かったですから、{買|か}いませんでした。{帰|かえ}りは{地下鉄|ちかてつ}でした。",
    q: [
      ["Dengan siapa pergi ke toserba?", ["Teman", "Keluarga", "Sendirian", "Guru"], 0],
      [
        "Di mana letak penjualan makanan?",
        ["Lantai 3", "Bawah tanah", "Lantai 1", "Di luar gedung"],
        1,
      ],
      ["Berapa harga satu apel?", ["150 yen", "100 yen", "1500 yen", "50 yen"], 0],
      ["Apa yang dibeli temannya?", ["Buah", "Daging dan ikan", "Sepatu", "Sayur"], 1],
      [
        "Mengapa sepatu tidak dibeli?",
        ["Tidak cocok", "Mahal", "Toko tutup", "Lupa membawa uang"],
        1,
      ],
      ["Pulang naik apa?", ["Bus", "Kereta bawah tanah", "Taksi", "Jalan kaki"], 1],
    ],
  },
  {
    lv: 2,
    n: "Pesta ulang tahun",
    t: "{先週|せんしゅう}の{土曜日|どようび}は{私|わたし}の{誕生日|たんじょうび}でした。{友達|ともだち}が5{人|にん}{家|うち}へ{来|き}ました。{私|わたし}は{朝|あさ}から{料理|りょうり}を{作|つく}りました。{友達|ともだち}は{花|はな}とケーキを{持|も}って{来|き}ました。みんなで{食|た}べて、{飲|の}んで、{歌|うた}を{歌|うた}いました。{夜|よる}10{時|じ}ごろ{友達|ともだち}は{帰|かえ}りました。とても{楽|たの}しい{日|ひ}でした。",
    q: [
      [
        "Hari apa ulang tahunnya?",
        ["Sabtu minggu lalu", "Minggu minggu lalu", "Sabtu hari ini", "Jumat kemarin"],
        0,
      ],
      ["Berapa teman yang datang?", ["3 orang", "4 orang", "5 orang", "10 orang"], 2],
      [
        "Apa yang dilakukan penulis sejak pagi?",
        ["Membeli kado", "Memasak", "Belajar", "Tidur"],
        1,
      ],
      [
        "Apa yang dibawa teman-teman?",
        ["Bunga dan kue", "Buku dan pensil", "Buah dan sayur", "Kopi dan teh"],
        0,
      ],
      [
        "Apa yang mereka lakukan bersama?",
        ["Menonton film", "Makan, minum, dan bernyanyi", "Berenang", "Belajar"],
        1,
      ],
      [
        "Kapan teman-teman pulang?",
        ["Sekitar jam 10 malam", "Sekitar jam 10 pagi", "Jam 12 siang", "Jam 6 sore"],
        0,
      ],
    ],
  },
  {
    lv: 3,
    n: "Pindah ke Jepang",
    t: "{私|わたし}の{名前|なまえ}はマリアです。{去年|きょねん}の4{月|がつ}にブラジルから{日本|にほん}へ{来|き}ました。{日本|にほん}の{会社|かいしゃ}で{働|はたら}いています。{会社|かいしゃ}は{東京|とうきょう}にあって、{社員|しゃいん}は{全部|ぜんぶ}で{百|ひゃく}{人|にん}ぐらいです。{初|はじ}めて{日本|にほん}へ{来|き}た{時|とき}は、{日本語|にほんご}があまりわかりませんでしたから、とても{心配|しんぱい}しました。でも、{会社|かいしゃ}の{人|ひと}は{親切|しんせつ}で、いろいろ{教|おし}えてくれました。{今|いま}は{会社|かいしゃ}の{近|ちか}くのアパートに{住|す}んでいます。{家賃|やちん}は{高|たか}いですが、{駅|えき}から{近|ちか}くて{便利|べんり}です。{休|やす}みの{日|ひ}は{友達|ともだち}と{公園|こうえん}を{散歩|さんぽ}したり、{映画|えいが}を{見|み}たりします。{来年|らいねん}は{家族|かぞく}を{日本|にほん}へ{呼|よ}びたいと{思|おも}っています。",
    q: [
      ["Dari negara mana penulis berasal?", ["Brasil", "Indonesia", "India", "Jerman"], 0],
      [
        "Kapan penulis datang ke Jepang?",
        ["April tahun lalu", "April tahun ini", "Mei tahun lalu", "April tahun depan"],
        0,
      ],
      [
        "Kira-kira berapa karyawan perusahaannya?",
        ["10 orang", "50 orang", "100 orang", "1000 orang"],
        2,
      ],
      [
        "Mengapa ia khawatir saat pertama datang?",
        [
          "Tidak punya teman",
          "Kurang mengerti bahasa Jepang",
          "Tidak punya pekerjaan",
          "Rumah terlalu jauh",
        ],
        1,
      ],
      [
        "Bagaimana sikap orang-orang di perusahaan?",
        ["Dingin", "Baik hati dan mengajarinya banyak hal", "Sibuk dan tidak peduli", "Pemarah"],
        1,
      ],
      [
        "Bagaimana apartemennya?",
        [
          "Murah tetapi jauh dari stasiun",
          "Mahal tetapi dekat stasiun dan praktis",
          "Murah dan dekat stasiun",
          "Mahal dan jauh",
        ],
        1,
      ],
      [
        "Apa yang dilakukan pada hari libur?",
        [
          "Berjalan-jalan di taman dan menonton film",
          "Bekerja lembur",
          "Belajar di perpustakaan",
          "Berenang di laut",
        ],
        0,
      ],
      [
        "Apa rencana tahun depan?",
        [
          "Pulang ke Brasil",
          "Memanggil keluarganya ke Jepang",
          "Pindah ke Osaka",
          "Berhenti bekerja",
        ],
        1,
      ],
    ],
  },
  {
    lv: 3,
    n: "Perjalanan ke Kyoto dan Nara",
    t: "{今年|ことし}の{秋|あき}、{私|わたし}は{友達|ともだち}の{山田|やまだ}さんと{二人|ふたり}で{京都|きょうと}と{奈良|なら}へ{旅行|りょこう}しました。{朝|あさ}7{時|じ}に{大阪|おおさか}を{出|で}て、{電車|でんしゃ}で{京都|きょうと}へ{行|い}きました。{京都|きょうと}では、まず{金閣寺|きんかくじ}を{見|み}ました。それから、{有名|ゆうめい}なレストランでお{昼|ひる}ごはんを{食|た}べました。{午後|ごご}は{紅葉|もみじ}がきれいな{公園|こうえん}を{歩|ある}きました。{晩|ばん}は{京都|きょうと}のホテルに{泊|と}まりました。{次|つぎ}の{日|ひ}は{奈良|なら}へ{行|い}きました。{奈良|なら}の{公園|こうえん}には{動物|どうぶつ}がたくさんいました。{動物|どうぶつ}に{食|た}べ{物|もの}をあげました。{奈良|なら}で{写真|しゃしん}をたくさん{撮|と}りました。{帰|かえ}りの{電車|でんしゃ}の{中|なか}で、{私|わたし}たちは{疲|つか}れましたから、{少|すこ}し{寝|ね}ました。{来年|らいねん}もまた{行|い}きたいです。",
    q: [
      [
        "Dengan siapa penulis bepergian?",
        ["Keluarga", "Yamada-san", "Rekan kantor", "Sendirian"],
        1,
      ],
      [
        "Perjalanan itu terjadi pada musim apa?",
        ["Musim semi", "Musim panas", "Musim gugur", "Musim dingin"],
        2,
      ],
      ["Berangkat dari kota mana jam 7 pagi?", ["Kyoto", "Nara", "Osaka", "Tokyo"], 2],
      [
        "Apa yang pertama dilihat di Kyoto?",
        ["Kuil Kinkakuji", "Benteng Osaka", "Gunung Fuji", "Stasiun Nara"],
        0,
      ],
      ["Makan siang di mana?", ["Di restoran terkenal", "Di kantin", "Di kereta", "Di hotel"], 0],
      [
        "Di mana mereka menginap?",
        ["Hotel di Kyoto", "Hotel di Nara", "Rumah teman", "Hotel di Osaka"],
        0,
      ],
      ["Apa yang banyak di taman Nara?", ["Hewan", "Toko", "Kuil kecil", "Mobil"], 0],
      [
        "Apa yang dilakukan di kereta saat pulang?",
        ["Membaca buku", "Tidur sebentar", "Makan malam", "Menelepon"],
        1,
      ],
    ],
  },
  {
    lv: 3,
    n: "Surat untuk Ibu",
    t: "お{母|かあ}さん、お{元気|げんき}ですか。{私|わたし}は{元気|げんき}です。{日本|にほん}は{今|いま}、{冬|ふゆ}です。とても{寒|さむ}いですが、{雪|ゆき}がきれいです。{先週|せんしゅう}、{初|はじ}めて{雪|ゆき}を{見|み}ました。{大学|だいがく}の{勉強|べんきょう}は{忙|いそが}しいですが、{毎日|まいにち}{楽|たの}しいです。{友達|ともだち}もたくさんできました。{日曜日|にちようび}は{友達|ともだち}の{家|うち}で{一緒|いっしょ}に{料理|りょうり}を{作|つく}ります。{日本|にほん}の{料理|りょうり}は{甘|あま}いものが{多|おお}いですが、{私|わたし}は{好|す}きです。{来月|らいげつ}、{大学|だいがく}の{試験|しけん}があります。{試験|しけん}が{終|お}わったら、{少|すこ}し{旅行|りょこう}したいです。{春|はる}になったら、{桜|さくら}を{見|み}に{行|い}きます。お{父|とう}さんにもよろしく。{体|からだ}に{気|き}をつけてください。",
    q: [
      ["Kepada siapa surat ini ditulis?", ["Ayah", "Ibu", "Teman", "Guru"], 1],
      [
        "Musim apa sekarang di Jepang?",
        ["Musim semi", "Musim panas", "Musim gugur", "Musim dingin"],
        3,
      ],
      [
        "Apa yang pertama kali dilihat minggu lalu?",
        ["Salju", "Bunga sakura", "Gunung Fuji", "Hujan"],
        0,
      ],
      [
        "Bagaimana kuliah penulis?",
        [
          "Sibuk tetapi menyenangkan",
          "Santai dan membosankan",
          "Sulit sehingga ingin berhenti",
          "Sangat mudah",
        ],
        0,
      ],
      [
        "Apa yang dilakukan hari Minggu di rumah teman?",
        ["Menonton film", "Memasak bersama", "Belajar", "Berolahraga"],
        1,
      ],
      [
        "Bagaimana penulis menilai masakan Jepang?",
        ["Banyak yang manis tetapi ia suka", "Semuanya pedas", "Tidak suka", "Terlalu asin"],
        0,
      ],
      [
        "Apa yang akan ada bulan depan?",
        ["Ujian universitas", "Ulang tahun", "Pindah rumah", "Liburan keluarga"],
        0,
      ],
      [
        "Apa rencana jika musim semi tiba?",
        ["Melihat bunga sakura", "Pulang kampung", "Berenang", "Belajar kanji"],
        0,
      ],
    ],
  },
);
function rsents(i) {
  return RS[i].t
    .split("。")
    .filter(function (x) {
      return x.replace(/\{(.+?)\|.+?\}/g, "$1").length >= 8;
    })
    .map(function (x) {
      return x + "。";
    });
}
function cerita() {
  S.rlv = S.rlv || 1;
  $("rv").innerHTML = [1, 2, 3]
    .map(function (l) {
      return (
        '<button class="chip' +
        (S.rlv === l ? " on" : "") +
        '" data-lv="' +
        l +
        '">Level ' +
        l +
        "</button>"
      );
    })
    .join("");
  $("rl").innerHTML = RS.map(function (r, i) {
    if ((r.lv || 1) !== S.rlv) return "";
    return (
      '<button class="bab" data-rs="' +
      i +
      '"><b>Cerita ' +
      (i + 1) +
      "</b><span>" +
      r.n +
      "<br>±" +
      r.t.replace(/\{(.+?)\|.+?\}/g, "$1").length +
      " huruf · " +
      r.q.length +
      " soal</span></button>"
    );
  }).join("");
}
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-lv]");
  if (b) {
    S.rlv = +b.getAttribute("data-lv");
    save();
    cerita();
  }
});
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-rs]");
  if (b && cur) {
    RI = +b.getAttribute("data-rs");
    GP = "R";
    GQ = true;
    show("play");
  }
});
// ===== Kanji =====
function kanji() {
  var t = W.filter(kw0).length;
  S.jn = Math.min(S.jn || 10, t);
  $("jq").max = t;
  $("jq").value = S.jn;
  $("js").textContent = "maks " + t;
  $("jc").innerHTML = [10, 25, 50, "Semua"]
    .map(function (n) {
      var v = n === "Semua" ? t : Math.min(n, t);
      return (
        '<button class="chip' +
        (S.jn === v ? " on" : "") +
        '" data-jn="' +
        v +
        '">' +
        (n === "Semua" ? "Semua (" + t + ")" : n + " soal") +
        "</button>"
      );
    })
    .join("");
}
$("jq").oninput = function () {
  var v = parseInt(this.value, 10);
  if (v > 0) {
    S.jn = Math.min(v, W.filter(kw0).length);
    save();
    Array.prototype.forEach.call($("jc").children, function (x) {
      x.classList.toggle("on", +x.getAttribute("data-jn") === S.jn);
    });
  }
};
$("jp").onclick = function () {
  GP = "J";
  GQ = true;
  show("play");
};
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-jn]");
  if (b) {
    S.jn = +b.getAttribute("data-jn");
    save();
    kanji();
  }
});
// ===== Mulai latihan khusus: kanji, cerita, kana, kata kerja =====
function startS() {
  var vs = GP === "K" || GP === "J" || GP === "R" ? [] : verbs(),
    n,
    L;
  if (GP === "J") {
    var kw = W.filter(kw0);
    n = Math.min(S.jn || 10, kw.length);
    L = take(
      "kj",
      kw,
      function (x) {
        return x.k + x.j;
      },
      n,
    ).map(function (x) {
      var md0 = Math.floor(Math.random() * 3);
      return { g: 1, p: "J", ty: 7, w: x, md: md0, rev: md0 > 0, t: mk(x), m: x.m };
    });
  } else if (GP === "R") {
    L = RS[RI].q.map(function (x, i) {
      return { g: 1, p: "R", ty: 8, i: i, t: x[0], m: x[1][x[2]] };
    });
    shuf(rsents(RI))
      .slice(0, 2)
      .forEach(function (z) {
        L.push({
          g: 1,
          p: "R",
          ty: 10,
          t: "Kalimat manakah yang ada di dalam cerita tadi?",
          m: gr(z),
          s: z,
        });
      });
  } else if (GP === "K") {
    var it2 = kitems();
    n = Math.min(S.kn || 10, it2.length);
    L = take(
      "k" + KT,
      it2,
      function (x) {
        return x.a + x.rev;
      },
      n,
    );
  } else if (GP === "G") {
    var gi = [];
    vs.forEach(function (v) {
      gi.push({ v: v, ty: 5 });
      gi.push({ v: v, ty: 9 });
    });
    n = Math.min(S.gg || 10, gi.length);
    L = take(
      "grp",
      gi,
      function (x) {
        return x.v.k + x.v.j + x.ty;
      },
      n,
    ).map(function (x) {
      return { g: 1, p: "G", ty: x.ty, v: x.v, t: mk(x.v), m: x.v.m };
    });
  } else {
    n = Math.min(S.gn || 10, 25);
    var F = ["te", "nai", "ta", "dict"];
    L = take(
      "vf",
      vs,
      function (v) {
        return v.k + v.j;
      },
      n,
    ).map(function (v) {
      return {
        g: 1,
        p: "V",
        ty: 4,
        v: v,
        f: F[Math.floor(Math.random() * 4)],
        idq: Math.random() < 0.5,
        t: mk(v),
        m: v.m,
      };
    });
  }
  Q = L;
  qi = 0;
  sc = 0;
  wr = [];
  $("pq").classList.remove("hide");
  $("pr").classList.add("hide");
  ask();
}
function grup() {
  var t = verbs().length * 2;
  S.gg = Math.min(S.gg || 10, t);
  $("gg").max = t;
  $("gg").value = S.gg;
  $("gs2").textContent = "maks " + t;
  $("ggc").innerHTML = [10, 25, 50, "Semua"]
    .map(function (n) {
      var v = n === "Semua" ? t : Math.min(n, t);
      return (
        '<button class="chip' +
        (S.gg === v ? " on" : "") +
        '" data-gg="' +
        v +
        '">' +
        (n === "Semua" ? "Semua (" + t + ")" : n + " soal") +
        "</button>"
      );
    })
    .join("");
}
$("gg").oninput = function () {
  var v = parseInt(this.value, 10);
  if (v > 0) {
    S.gg = Math.min(v, verbs().length * 2);
    save();
    Array.prototype.forEach.call($("ggc").children, function (x) {
      x.classList.toggle("on", +x.getAttribute("data-gg") === S.gg);
    });
  }
};
$("ggp").onclick = function () {
  GP = "G";
  GQ = true;
  show("play");
};
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-gg]");
  if (b) {
    S.gg = +b.getAttribute("data-gg");
    save();
    grup();
  }
});
function startG() {
  GM = true;
  if (GP === "G" || GP === "V" || GP === "K" || GP === "J" || GP === "R") return startS();
  var n = Math.min(S.gn || 10, 25),
    used = {},
    list = [],
    len = GD[GP].length;
  while (list.length < n) {
    take(
      "g" + GP,
      GD[GP].map(function (x, i) {
        return i;
      }),
      String,
      Math.min(len, n - list.length),
    ).forEach(function (i) {
      var u = used[i] || (used[i] = []),
        ts = [1, 2, 3].filter(function (t) {
          return u.indexOf(t) < 0;
        }),
        t = ts[Math.floor(Math.random() * ts.length)];
      u.push(t);
      list.push({ g: 1, p: GP, t: GD[GP][i][0], m: GD[GP][i][1], ty: t });
    });
  }
  Q = shuf(list);
  qi = 0;
  sc = 0;
  wr = [];
  $("pq").classList.remove("hide");
  $("pr").classList.add("hide");
  ask();
}
// ===== Menampilkan soal untuk mode latihan =====
function askG(w) {
  lock = false;
  var pl = GD[w.p],
    plain = function (t) {
      return gr(t.replace(/\*/g, ""));
    },
    q,
    ans,
    opts;
  if (w.ty === 7) {
    var wd = w.w,
      sk = simK(wd.j),
      seen = {},
      oth = [],
      t0 = w.rev ? wd.j : wd.k;
    W.filter(function (x) {
      return kw0(x) && x.k !== wd.k && x.j !== wd.j;
    })
      .map(function (x) {
        var s = Math.random() * 2,
          i;
        for (i = 0; i < x.j.length; i++) {
          if (wd.j.indexOf(x.j[i]) > -1) s += 3;
          if (sk.indexOf(x.j[i]) > -1) s += 3;
        }
        if (x.j.length === wd.j.length) s++;
        return [s, x];
      })
      .sort(function (a, b) {
        return b[0] - a[0];
      })
      .forEach(function (pp) {
        var h = w.rev ? pp[1].j : pp[1].k;
        if (oth.length < 4 && !seen[h] && h !== t0) {
          seen[h] = 1;
          oth.push({ h: h, ok: false });
        }
      });
    var fk = fake(wd.j);
    if (
      w.rev &&
      fk &&
      fk !== t0 &&
      oth.length &&
      !oth.some(function (o) {
        return o.h === fk;
      })
    )
      oth[oth.length - 1] = { h: fk, ok: false };
    q =
      w.md === 2
        ? '<div class="big id">' +
          wd.m +
          '</div><div style="color:var(--mute)">Pilih kanji yang tepat</div>'
        : w.rev
          ? '<div class="big">' +
            wd.k +
            '</div><div style="color:var(--mute)">Pilih kanji yang tepat. Arti: ' +
            wd.m +
            "</div>"
          : '<div class="big">' +
            wd.j +
            '</div><div style="color:var(--mute)">Bagaimana cara membacanya?</div>';
    ans = t0;
    opts = shuf(oth.concat([{ h: t0, ok: true }]));
  } else if (w.ty === 8) {
    q =
      '<div class="story">' +
      gr(RS[RI].t) +
      '</div><div class="big id" style="font-size:19px">' +
      w.t +
      "</div>";
    ans = w.m;
    opts = shuf(
      RS[RI].q[w.i][1]
        .map(function (o, i) {
          return { h: o, ok: i === RS[RI].q[w.i][2] };
        })
        .concat([{ h: "Tidak disebutkan dalam cerita", ok: false }]),
    );
  } else if (w.ty === 6) {
    var kp2 = kpool(),
      a0 = w.rev ? w.a : w.r,
      sn = {},
      oth = [];
    q = w.rev
      ? '<div class="big id">' + w.r + '</div><div style="color:var(--mute)">Pilih hurufnya</div>'
      : '<div class="big">' +
        w.a +
        '</div><div style="color:var(--mute)">Bagaimana cara bacanya?</div>';
    var sg = (KT === "hira" ? SIMH : SIMK)
        .filter(function (g) {
          return g.indexOf(w.a[0]) > -1;
        })
        .join(""),
      al2 = [];
    KI(KT).forEach(function (g) {
      g.forEach(function (x) {
        if (x) al2.push(x);
      });
    });
    shuf(al2)
      .sort(function (a, b) {
        return (sg.indexOf(a[0][0]) > -1 ? 0 : 1) - (sg.indexOf(b[0][0]) > -1 ? 0 : 1);
      })
      .forEach(function (x) {
        var h = w.rev ? x[0] : x[1];
        if (oth.length < 4 && h !== a0 && !sn[h]) {
          sn[h] = 1;
          oth.push({ h: h, ok: false });
        }
      });
    ans = a0;
    opts = shuf(oth.concat([{ h: a0, ok: true }]));
  } else if (w.ty === 4) {
    var fm = forms(w.v),
      LB = { te: "bentuk て", nai: "bentuk ない", ta: "bentuk た", dict: "bentuk kamus" };
    q =
      '<div class="big gj">' +
      gr(w.t) +
      '</div><div style="color:var(--mute)">' +
      w.m +
      "<br>Pilih " +
      LB[w.f] +
      " dari kata kerja ini.</div>";
    if (w.idq)
      q =
        '<div class="big id">' +
        w.m +
        '</div><div style="color:var(--mute)">Pilih ' +
        LB[w.f] +
        " dari kata kerja yang berarti ini.</div>";
    ans = fm[w.f];
    opts = shuf(
      vwrong(w.v, w.f, fm)
        .map(function (x) {
          return { h: x, ok: false };
        })
        .concat([{ h: fm[w.f], ok: true }]),
    );
  } else if (w.ty === 5) {
    var gg = w.v.g,
      k = w.v.k,
      st = k.slice(0, -2),
      pre = k.slice(0, -3),
      l = st.slice(-1),
      E2U = {
        え: "う",
        け: "く",
        せ: "す",
        て: "つ",
        ね: "ぬ",
        へ: "ふ",
        め: "む",
        れ: "る",
        げ: "ぐ",
        ぜ: "ず",
        で: "づ",
        べ: "ぶ",
        ぺ: "ぷ",
      },
      GL = ["", "I", "II", "III"],
      dk = {
        1: UU[l] ? pre + UU[l] : E2U[l] ? pre + E2U[l] : null,
        2: st + "る",
        3: k.slice(-3) === "きます" ? pre + "くる" : k.slice(-3) === "します" ? pre + "する" : null,
      },
      tr = forms(w.v).dict,
      cd = [];
    [1, 2, 3].forEach(function (g) {
      [1, 2, 3].forEach(function (d) {
        if (dk[d] && !(g === gg && dk[d] === tr)) cd.push({ g: g, d: dk[d] });
      });
    });
    q =
      '<div class="big gj">' +
      gr(w.t) +
      '</div><div style="color:var(--mute)">' +
      w.m +
      "<br>Termasuk kelompok berapa dan apa bentuk kamusnya?</div>";
    ans = "Kelompok " + GL[gg] + " (bentuk kamus: " + tr + ")";
    opts = shuf(
      shuf(cd)
        .slice(0, 4)
        .map(function (c) {
          return { h: "Kelompok " + GL[c.g] + " (" + c.d + ")", ok: false };
        })
        .concat([{ h: "Kelompok " + GL[gg] + " (" + tr + ")", ok: true }]),
    );
  } else if (w.ty === 9) {
    var g9 = w.v.g,
      p9 = verbs().filter(function (v) {
        return v.g !== g9 && v.k !== w.v.k;
      });
    q =
      '<div class="big id" style="font-size:22px">Pilih kata kerja yang termasuk Kelompok ' +
      ["", "I", "II", "III"][g9] +
      "</div>";
    ans = w.v.k + (w.v.j ? " (" + w.v.j + ")" : "");
    opts = shuf(
      p9
        .map(function (x) {
          return [simw(w.v, x), x];
        })
        .sort(function (a, b) {
          return b[0] - a[0];
        })
        .slice(0, 4)
        .map(function (x) {
          return { h: rb(x[1], S.furi), ok: false };
        })
        .concat([{ h: rb(w.v, S.furi), ok: true }]),
    );
  } else if (w.ty === 10) {
    var ss = [];
    RS.forEach(function (r, i) {
      if (i !== RI)
        rsents(i).forEach(function (x) {
          ss.push(x);
        });
    });
    q = '<div class="big id" style="font-size:20px">' + w.t + "</div>";
    ans = gr(w.s);
    opts = shuf(
      shuf(ss)
        .slice(0, 4)
        .map(function (x) {
          return { h: gr(x), ok: false };
        })
        .concat([{ h: ans, ok: true }]),
    );
  } else if (w.ty === 2) {
    q =
      '<div class="big gj">' +
      gr(w.t.replace(/\*(.+?)\*/g, "*＿＿*")) +
      '</div><div style="color:var(--mute)">' +
      w.m +
      "<br>Partikel apa yang cocok?</div>";
    ans = w.p;
    opts = shuf(CONF[w.p].slice(0, 4).concat([w.p])).map(function (k) {
      return { h: k, ok: k === w.p };
    });
  } else if (w.ty === 3) {
    q =
      '<div class="big id">' +
      w.m +
      '</div><div style="color:var(--mute)">Pilih kalimat Jepang yang tepat. Partikel: <b>' +
      w.p +
      "</b></div>";
    ans = plain(w.t);
    opts = shuf(
      shuf(
        pl.filter(function (x) {
          return x[0] !== w.t;
        }),
      )
        .slice(0, 4)
        .map(function (x) {
          return { h: plain(x[0]), ok: false };
        })
        .concat([{ h: ans, ok: true }]),
    );
  } else {
    var all = [],
      same = [];
    Object.keys(GD).forEach(function (k) {
      GD[k].forEach(function (x) {
        if (x[1] !== w.m) {
          if (k === w.p) same.push(x[1]);
          else all.push(x[1]);
        }
      });
    });
    all = shuf(same).concat(shuf(all));
    q =
      '<div class="big gj">' +
      gr(w.t) +
      '</div><div style="color:var(--mute)">Apa artinya? Partikel: <b>' +
      w.p +
      "</b></div>";
    ans = w.m;
    opts = shuf(
      all
        .slice(0, 4)
        .map(function (m) {
          return { h: m, ok: false };
        })
        .concat([{ h: w.m, ok: true }]),
    );
  }
  w.ans = ans;
  $("pn").textContent = "Soal " + (qi + 1) + " dari " + Q.length;
  $("ps").textContent = "Skor " + sc;
  $("pb").style.width = (qi / Q.length) * 100 + "%";
  $("fb").textContent = "";
  $("nx").classList.add("hide");
  $("qt").innerHTML = q;
  var box = $("qo");
  box.innerHTML = "";
  opts.forEach(function (o) {
    var b = document.createElement("button");
    b.className =
      "opt" +
      (w.ty === 2 || w.ty === 4 || w.ty === 7 || w.ty === 9 || (w.ty === 6 && w.rev) ? " jp" : "");
    b.innerHTML = o.h;
    b.setAttribute("data-ok", o.ok ? "1" : "0");
    b.onclick = function () {
      pick(b, o.ok, w);
    };
    box.appendChild(b);
  });
}
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-p]");
  if (b && cur) {
    GP = b.getAttribute("data-p");
    GQ = true;
    show("play");
  }
});
$("again").onclick = function () {
  GM ? startG() : start();
};

// ===== Setting =====
function seg(id, items, isOn, fn) {
  var c = $(id);
  c.innerHTML = "";
  items.forEach(function (it) {
    var b = document.createElement("button");
    b.className = "chip" + (isOn(it[0]) ? " on" : "");
    b.textContent = it[1];
    b.setAttribute("aria-pressed", isOn(it[0]));
    b.onclick = function () {
      fn(it[0]);
      save();
      setting();
      $("sm").textContent = "Tersimpan.";
    };
    c.appendChild(b);
  });
}
function setting() {
  $("sm").textContent = "";
  seg(
    "gm",
    [
      ["mix", "Campur (acak)"],
      ["jp", "Jepang → Indonesia"],
      ["id", "Indonesia → Jepang"],
    ],
    function (v) {
      return (S.dir || "mix") === v;
    },
    function (v) {
      S.dir = v;
    },
  );
  seg(
    "gf",
    [
      [true, "Tampilkan"],
      [false, "Sembunyikan"],
    ],
    function (v) {
      return S.furi === v;
    },
    function (v) {
      S.furi = v;
    },
  );
  seg(
    "gs",
    [
      [true, "Nyala"],
      [false, "Mati"],
    ],
    function (v) {
      return S.snd === v;
    },
    function (v) {
      S.snd = v;
    },
  );
  seg(
    "gt",
    [
      ["auto", "Otomatis (ikut HP)"],
      ["light", "Terang"],
      ["dark", "Gelap"],
    ],
    function (v) {
      return (S.theme || "auto") === v;
    },
    function (v) {
      S.theme = v;
      theme();
    },
  );
}
$("rst").onclick = function () {
  if (!cur) return;
  users[cur] = Object.assign(users[cur], { best: 0, played: 0, right: 0, total: 0, h: [] });
  save();
  $("sm").textContent = "Skor direset.";
};

theme();
show(cur && users[cur] ? "home" : "login");
cloudInit();
